# VelQora — AI Pre-Meeting Briefing Agent

VelQora turns a company or person name, a meeting time and a meeting purpose into a **source-backed pre-meeting
briefing**. It researches the **last 30 days** with Tavily, drafts an analysis through the Bifrost LLM gateway,
**checks every factual claim against the retrieved source text**, and shows the result with the sources attached.

> Nothing is faked. If Tavily or Bifrost is not configured, VelQora returns a clear error or a clearly labelled
> reduced briefing — never invented data.

---

## 1. Overview

| | |
|---|---|
| **Frontend** | Plain HTML + CSS + vanilla JavaScript (no framework, no build step) |
| **Backend** | FastAPI, Pydantic, SQLite (Python standard library), asynchronous job + polling |
| **Research** | Tavily search API (bounded, credit-aware) |
| **AI** | Bifrost (OpenAI-compatible LLM gateway by Maxim AI); the model is configuration only |
| **Verification** | Deterministic text-grounding check — no extra LLM tokens |

## 2. Problem statement

Preparing for a meeting means gathering recent news, products, leadership and market context from many places, and
it is hard to tell which statements are actually backed by a source. AI summaries make this worse when they state
unsupported claims with confidence.

## 3. Proposed solution

VelQora automates the research and drafting, and separates *what a retrieved source actually says* from *what the AI
wrote*. Every factual claim is compared with the retrieved source text and labelled; AI-written talking points are
always labelled as AI analysis and never counted as verified.

## 4. Key features

- Three-page workflow: landing page → research setup → company intelligence report.
- Three research depths: `quick`, `standard`, `deep` (bounded number of Tavily searches).
- 30-day recency window, with undated or older sources kept out of the "recent developments" section.
- Claim-to-source mapping with evidence states (`supported`, `partially_supported`, `conflicting`, `unsupported`,
  `unverified`, `outdated`).
- Source cards show the original URL, domain, publication date (when available), retrieval time and snippet.
- Asynchronous jobs with server-reported progress; Page 3 resumes by research ID after a refresh and never starts a
  second research request.
- Optional accounts (scrypt-hashed passwords, JWT); research works without signing in by default.
- Input validation (including URL checks that reject private/loopback hosts), per-IP rate limits, security headers,
  secret scrubbing in logs.
- Printable one-page briefing (`briefing.html`) and a printable report on Page 3.

## 5. Technology stack

| Layer | Technology |
|---|---|
| Frontend | HTML5, CSS3, vanilla JavaScript |
| Backend | Python 3.10+, FastAPI, Uvicorn, Pydantic v2, httpx, python-dotenv, python-dateutil, PyJWT |
| Database | SQLite via the standard-library `sqlite3` module |
| Research | Tavily API |
| LLM | Bifrost gateway (OpenAI-compatible `/v1/chat/completions` and `/v1/models`) |
| Tests | pytest (backend), Node.js built-in test runner (frontend) |

## 6. System architecture

```
Browser (vanilla JS)                                                     FastAPI backend
 index.html ── hand-off ──► research-setup.html ── POST /api/research ─► job (SQLite)
                                                                            │
 research-results.html?id=… ◄── GET /api/research/{id} ◄────────────────────┤
       │                                                                    ├─ 1 validate input (URL checks)
       ├─ GET /api/briefing/{briefing_id} ◄─────────────────────────────────┤─ 2 ResearchAgent ──► TavilyService ──► Tavily API
       ▼                                                                    ├─ 3 clean · dedupe · rank sources
 render the saved report                                                    ├─ 4 date validation (30-day window)
 briefing.html remains available separately                                 ├─ 5 AnalysisAgent ──► BifrostService ──► Bifrost ──► LLM
                                                                            ├─ 6 claim mapping + verification (deterministic)
                                                                            └─ 7 BriefingAgent ─► validated JSON (Pydantic) ─► SQLite
```

More detail: [docs/ARCHITECTURE.md](docs/ARCHITECTURE.md) and [docs/WORKFLOW.md](docs/WORKFLOW.md).

### How trust is handled

| Label | Meaning |
|---|---|
| **verified** | Numbers, names and key words of the claim were found in a retrieved source (source IDs attached). For *recent developments* the source must also have a reliable date inside the 30-day window. |
| **undated / outdated** | Grounded in a source, but that source has no reliable date or is older than 30 days → shown under "Not confirmed as recent", never as a recent development. |
| **unverified** | Could not be matched to any source → excluded from every verified section, listed separately. |
| **analysis** | AI-written talking points, questions, risks, opportunities → always labelled *AI analysis*, never counted as verified. |
| **unavailable** | A gap (no sources, no people found, AI down…) reported as an *open question* instead of being filled in. |

"Verified" is a **grounding check** (the wording is in the source), not proof that the source is correct. Tune
strictness with `VERIFY_MIN_OVERLAP`. Dates come from Tavily's `published_date`; a strict `/YYYY/MM/DD/` URL pattern
is the fallback (`date_source: "url"`); otherwise the source is `undated`.

## 7. Frontend and backend explanation

**Frontend (`frontend/`)** — five pages in `pages/`, styles in `assets/css/`, scripts in `assets/js/`.

| Page | File | Role |
|---|---|---|
| Page 1 | `pages/index.html` | Landing page; the input card hands the entered details to Page 2 (stored in `sessionStorage`). The animated demo is cosmetic. |
| Page 2 | `pages/research-setup.html` | Research configuration; submits the **one** `POST /api/research` request, then opens Page 3 with the returned job ID. |
| Page 3 | `pages/research-results.html?id=…` | Polls that job, fetches the saved briefing and renders the report. Never starts new research. |
| — | `pages/briefing.html?id=…` | Original one-page printable briefing. |
| — | `pages/signin.html` | Optional sign in / create account. |

`assets/js/api.js` is the **only** place the frontend talks to the backend. No API keys exist in the frontend.

**Backend (`backend/app/`)** — `main.py` builds the app, `config.py` reads environment variables, `api/routes/` holds
the HTTP endpoints, `agents/` the research / analysis / verification / briefing logic, `services/` the Tavily and
Bifrost clients and the job lifecycle, `schemas/` the Pydantic models, `database/` the SQLite repositories and
`utils/` validation, date and source helpers. FastAPI also serves the `frontend/` folder, so the app is reachable on
a single origin at `http://localhost:8000/`.

## 8. Folder structure

```
VelQora/
├── frontend/
│   ├── pages/            index · research-setup · research-results · briefing · signin (.html)
│   ├── assets/
│   │   ├── css/          variables · global · animations · components · responsive · setup · research-results
│   │   └── js/           api · auth · app · research · setup · research-results · briefing
│   ├── tests/            workflow.test.cjs   (Node.js mocked three-page workflow tests)
│   └── README.md
├── backend/
│   ├── app/
│   │   ├── main.py  config.py  dependencies.py  security.py  exceptions.py
│   │   ├── api/routes/   health · research · briefing · auth
│   │   ├── agents/       research · analysis · verification · briefing · prompts
│   │   ├── services/     tavily · bifrost · research · briefing · source · claim_mapping · source_verification · http_client
│   │   ├── schemas/      research · briefing · auth
│   │   ├── utils/        date_utils · source_utils · validation
│   │   └── database/     connection · models
│   ├── tests/            test_health · test_research · test_briefing · test_source_verification (+ helpers, conftest)
│   ├── requirements.txt
│   └── .env.example
├── docs/
│   ├── ARCHITECTURE.md  WORKFLOW.md  API_DOCUMENTATION.md  HACKATHON_GUIDE.md  TESTING_REPORT.md
│   └── archive/          historical audit notes and Phase 1 originals (not used at runtime)
├── scripts/
│   ├── run_windows.bat
│   └── run_linux_mac.sh
├── .gitignore
├── CONTRIBUTING.md
└── README.md
```

## 9. Installation

**Prerequisites**

- Python **3.10 or newer** (3.12 recommended)
- A Tavily API key — <https://app.tavily.com>
- A running Bifrost gateway with one LLM provider configured (needs Node.js **or** Docker to start Bifrost; see
  step 3 of [Environment configuration](#10-environment-variable-configuration))
- Node.js — **only** to run the frontend tests (the built-in test runner; Node 20+ recommended)

**Quick start (recommended)** — the startup scripts create `backend/.venv`, install `requirements.txt`, copy
`.env.example` to `.env` if there is none, and start the server:

```bash
# Linux / macOS
./scripts/run_linux_mac.sh
```
```bat
:: Windows (double-click, or from a terminal)
scripts\run_windows.bat
```

**Manual installation**

```bash
cd backend
python -m venv .venv
source .venv/bin/activate            # Windows: .venv\Scripts\activate
pip install -r requirements.txt
cp .env.example .env                 # Windows: copy .env.example .env
```

## 10. Environment variable configuration

All configuration lives in `backend/.env` (git-ignored). The scripts never write keys for you.
Every variable is documented in `backend/.env.example`; the required ones are:

| Variable | Purpose |
|---|---|
| `TAVILY_API_KEY` | Enables web research. Without it `POST /api/research` returns `503 tavily_not_configured`. |
| `BIFROST_BASE_URL` | Address of your Bifrost gateway (default in the template: `http://localhost:8080`). |
| `BIFROST_MODEL` | Exact model id in the form `provider/model-name` (copy it from `GET <bifrost>/v1/models`). Without it the briefing is built without AI analysis and is labelled as such. |
| `BIFROST_API_KEY` | Only if your Bifrost enforces auth / virtual keys (`BIFROST_AUTH_MODE=virtual_key` sends it as `x-bf-vk`). |
| `JWT_SECRET` | Leave blank to auto-generate a temporary secret (logins reset on restart); set a long random value for real use. |
| `REQUIRE_AUTH` | `false` (default) = research works without signing in; `true` = research calls need a token. |

**Tavily.** The free plan includes a monthly credit allowance. Depths: `quick` runs up to 2 basic searches,
`standard` up to 4 basic searches, `deep` up to 6 advanced searches (up to 12 credits). `TAVILY_MAX_SEARCHES_PER_RESEARCH`
(default 6) caps all modes, identical searches are cached for 6 h, `TAVILY_DAILY_CALL_CAP` (default 100) is a hard
stop and per-IP rate limits apply (`RESEARCH_RATE_LIMIT_PER_HOUR`, default 12).

**Bifrost.** This project uses **Bifrost by Maxim AI** ([github.com/maximhq/bifrost](https://github.com/maximhq/bifrost),
docs: <https://docs.getbifrost.ai>), a self-hosted gateway with an OpenAI-compatible API.

1. Start it (check the official quickstart for the current command; at the time of writing):
   ```bash
   npx -y @maximhq/bifrost          # serves on http://localhost:8080
   # or: docker run -p 8080:8080 maximhq/bifrost
   ```
2. Open <http://localhost:8080>, add a **provider** and its API key. Bifrost provides no tokens itself — check your
   provider's current free-tier terms.
3. List model ids: `curl http://localhost:8080/v1/models`.
4. Set `BIFROST_BASE_URL` and `BIFROST_MODEL` in `backend/.env`.

Switching models means changing `BIFROST_MODEL` (and optionally `BIFROST_MAX_TOKENS`) and restarting.

## 11. How to run the project

```bash
./scripts/run_linux_mac.sh          # Linux / macOS
scripts\run_windows.bat             # Windows
```

Or manually:

```bash
cd backend
uvicorn app.main:app --reload --port 8000
```

Open **<http://localhost:8000/>** — FastAPI serves the frontend from the same origin. Interactive API docs:
<http://localhost:8000/api/docs> (disabled when `APP_ENV=production`).

> Keep the port at **8000**: `frontend/assets/js/api.js` treats port 8000 as "same origin" and otherwise assumes the
> backend is at `http://localhost:8000`.

Alternative — serve `frontend/` separately and keep the backend on port 8000:

```bash
cd frontend && python -m http.server 5500     # then open http://localhost:5500/pages/index.html
```

`api.js` then calls `http://localhost:8000` automatically on localhost; override with
`<script>window.VELQORA_API_BASE="https://your-api"</script>` before `api.js`, and add the frontend origin to
`CORS_ORIGINS`.

Check that everything is wired: `curl localhost:8000/api/health/services` (add `?deep=true` to also run a tiny model
call).

## 12. How to test the project

```bash
# Backend (no network or API keys needed — Tavily and Bifrost are replaced by fake transports)
cd backend
pip install -r requirements.txt
pytest -q

# Frontend workflow tests (Node.js mocks, no credentials needed)
cd frontend
node --test tests/workflow.test.cjs
```

Live checks need your keys: `GET /api/health/services?deep=true`, then run a real research from the UI.
Results of the latest verification run, including what could **not** be run, are in
[docs/TESTING_REPORT.md](docs/TESTING_REPORT.md).

## 13. API overview

| Method & path | Purpose |
|---|---|
| `GET /api/health` | Backend is up |
| `GET /api/health/services[?deep=true]` | FastAPI / Tavily / Bifrost configuration + connectivity (no secrets returned) |
| `POST /api/research` | Validate input and start an async job → `202 {research_id, status, stage, progress…}` |
| `GET /api/research/{id}` | Status (`queued/running/completed/failed`), stage, progress, sources, `briefing_id` |
| `POST /api/briefing/generate` | `{research_id, force?}` — generate a briefing from finished research (idempotent) |
| `GET /api/briefing/{id}` | Status + the validated briefing JSON |
| `POST /api/auth/register` · `POST /api/auth/login` · `GET /api/auth/me` | Optional accounts |

Full request/response details, error codes and examples: [docs/API_DOCUMENTATION.md](docs/API_DOCUMENTATION.md).

## 14. Important security considerations

- Keys stay in `backend/.env` (git-ignored) and are never sent to the browser; log lines are scrubbed of key-like strings.
- Never commit a real `.env`, API key, password or JWT secret. `backend/.env.example` holds placeholders only.
- The backend never fetches user-supplied URLs; URLs are still validated (http/https only, no private/loopback/internal
  hosts, no credentials or unusual ports).
- Web text is untrusted: HTML is stripped, instruction-like sentences are removed, the text is passed to the model as
  delimited data, and the model output is accepted only after source verification. The frontend escapes dynamic values.
- Per-IP rate limits, request timeouts, retries with backoff, safe error messages, security headers and a CSP on pages.
- Set a strong `JWT_SECRET` and `APP_ENV=production` for anything beyond a local demo.

## 15. Known limitations

- A "verified" label means the wording was found in a retrieved snippet; it does not prove the publisher is reliable.
- The JWT is kept in the browser's `localStorage`; the rate limiter, Tavily cache and job runner are in-process; SQLite
  is single-node. These are prototype choices (production would use httpOnly cookies, a shared store and a worker queue).
- Research and AI analysis need your own Tavily key and a configured Bifrost gateway with a provider key. Without them
  the app reports what is missing instead of producing results.
- A job that is interrupted by a server restart is marked as failed on the next start; it is not resumed.
- The full pipeline has been tested here only with fake Tavily/Bifrost transports (see the testing report); a live
  end-to-end run against the real services must be done with your own credentials.

## 16. Future improvements

Ideas only — none of these are implemented:

- httpOnly-cookie sessions instead of `localStorage` tokens.
- A shared cache / rate limiter and a worker queue for multi-instance deployment.
- A PostgreSQL repository behind the existing repository interface.
- Export of the report to PDF/Word from the server side.

---

See also: [CONTRIBUTING.md](CONTRIBUTING.md) · [docs/HACKATHON_GUIDE.md](docs/HACKATHON_GUIDE.md) ·
[frontend/README.md](frontend/README.md)
