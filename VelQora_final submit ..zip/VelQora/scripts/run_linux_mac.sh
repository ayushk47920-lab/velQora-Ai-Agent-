#!/usr/bin/env bash
# VelQora - start the backend (which also serves the frontend) on Linux or macOS.
# Usage:  ./scripts/run_linux_mac.sh        (run from anywhere)
# It never creates or invents API keys: if backend/.env is missing it copies the placeholder
# file .env.example, and you must add your own TAVILY_API_KEY / Bifrost settings.
set -euo pipefail

ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
BACKEND="$ROOT/backend"
cd "$BACKEND"

# 1. Find Python 3.10+ ------------------------------------------------------------------------
PY=""
for candidate in python3.13 python3.12 python3.11 python3.10 python3 python; do
  if command -v "$candidate" >/dev/null 2>&1 &&
     "$candidate" -c 'import sys; sys.exit(0 if sys.version_info >= (3, 10) else 1)' >/dev/null 2>&1; then
    PY="$candidate"
    break
  fi
done
if [ -z "$PY" ]; then
  echo "ERROR: Python 3.10 or newer was not found. Install it from https://www.python.org/downloads/ and retry." >&2
  exit 1
fi
echo "Using $($PY --version 2>&1) ($(command -v "$PY"))"

# 2. Virtual environment + dependencies ------------------------------------------------------------
if [ ! -x ".venv/bin/python" ]; then
  echo "Creating virtual environment in backend/.venv ..."
  "$PY" -m venv .venv
fi
VENV_PY="$BACKEND/.venv/bin/python"

echo "Installing/Checking dependencies from backend/requirements.txt ..."
if ! "$VENV_PY" -m pip install -q -r requirements.txt; then
  if "$VENV_PY" -c 'import fastapi, uvicorn, pydantic, httpx, dotenv, dateutil, jwt' >/dev/null 2>&1; then
    echo "WARNING: dependency install failed (offline?), but the required packages are already installed. Continuing." >&2
  else
    echo "ERROR: could not install dependencies. Check your internet connection and run again." >&2
    exit 1
  fi
fi

# 3. Environment file ------------------------------------------------------------------------------
if [ ! -f ".env" ]; then
  cp ".env.example" ".env"
  echo
  echo "Created backend/.env from the placeholder template (.env.example)."
  echo "It contains NO keys. Open backend/.env and add your own values before running real research."
fi

env_value() { grep -E "^$1=" .env 2>/dev/null | tail -n 1 | cut -d= -f2- | tr -d '[:space:]"' || true; }
echo
if [ -z "$(env_value TAVILY_API_KEY)" ]; then
  echo "NOTE: TAVILY_API_KEY is empty in backend/.env - starting research will return 'tavily_not_configured'."
fi
if [ -z "$(env_value BIFROST_MODEL)" ]; then
  echo "NOTE: BIFROST_MODEL is empty in backend/.env - briefings will be created without AI analysis (clearly labelled)."
fi

# 4. Start the server ------------------------------------------------------------------------------
# Port 8000 is what the frontend expects (see frontend/assets/js/api.js).
echo
echo "Starting VelQora at http://localhost:8000/   (API docs: http://localhost:8000/api/docs)"
echo "Press Ctrl+C to stop."
exec "$VENV_PY" -m uvicorn app.main:app --host 127.0.0.1 --port 8000
