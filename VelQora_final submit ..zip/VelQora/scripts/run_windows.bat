@echo off
rem VelQora - start the backend (which also serves the frontend) on Windows.
rem Double-click this file or run it from a terminal:  scripts\run_windows.bat
rem It never creates or invents API keys: if backend\.env is missing it copies the placeholder
rem file .env.example, and you must add your own TAVILY_API_KEY / Bifrost settings.
setlocal EnableExtensions
title VelQora

pushd "%~dp0..\backend"
if errorlevel 1 (
  echo ERROR: could not open the backend folder.
  goto :fail
)

rem ---- 1. Find Python 3.10+ -------------------------------------------------------------
set "PYCMD="
where py >nul 2>nul
if not errorlevel 1 (
  py -3 -c "import sys; sys.exit(0 if sys.version_info >= (3, 10) else 1)" >nul 2>nul
  if not errorlevel 1 set "PYCMD=py -3"
)
if not defined PYCMD (
  where python >nul 2>nul
  if not errorlevel 1 (
    python -c "import sys; sys.exit(0 if sys.version_info >= (3, 10) else 1)" >nul 2>nul
    if not errorlevel 1 set "PYCMD=python"
  )
)
if not defined PYCMD (
  echo ERROR: Python 3.10 or newer was not found.
  echo Install it from https://www.python.org/downloads/ and tick "Add python.exe to PATH".
  echo If Windows opens the Microsoft Store instead, disable the python.exe "App execution alias" in Settings.
  goto :fail
)
echo Using: %PYCMD%

rem ---- 2. Virtual environment + dependencies --------------------------------------------
if not exist ".venv\Scripts\python.exe" (
  echo Creating virtual environment in backend\.venv ...
  %PYCMD% -m venv .venv
  if errorlevel 1 goto :fail
)
set "VENV_PY=%CD%\.venv\Scripts\python.exe"

echo Installing/Checking dependencies from backend\requirements.txt ...
"%VENV_PY%" -m pip install -q -r requirements.txt
if errorlevel 1 (
  "%VENV_PY%" -c "import fastapi, uvicorn, pydantic, httpx, dotenv, dateutil, jwt" >nul 2>nul
  if errorlevel 1 (
    echo ERROR: could not install dependencies. Check your internet connection and run again.
    goto :fail
  )
  echo WARNING: dependency install failed, but the required packages are already installed. Continuing.
)

rem ---- 3. Environment file --------------------------------------------------------------
if not exist ".env" (
  copy ".env.example" ".env" >nul
  echo.
  echo Created backend\.env from the placeholder template .env.example.
  echo It contains NO keys. Open backend\.env and add your own values before running real research.
)
findstr /R /C:"^TAVILY_API_KEY=[^ ]" ".env" >nul 2>nul
if errorlevel 1 echo NOTE: TAVILY_API_KEY is empty in backend\.env - starting research will return tavily_not_configured.
findstr /R /C:"^BIFROST_MODEL=[^ ]" ".env" >nul 2>nul
if errorlevel 1 echo NOTE: BIFROST_MODEL is empty in backend\.env - briefings will be created without AI analysis, clearly labelled.

rem ---- 4. Start the server --------------------------------------------------------------
rem Port 8000 is what the frontend expects (see frontend\assets\js\api.js).
echo.
echo Starting VelQora at http://localhost:8000/   API docs: http://localhost:8000/api/docs
echo Press Ctrl+C to stop.
"%VENV_PY%" -m uvicorn app.main:app --host 127.0.0.1 --port 8000
popd
pause
exit /b 0

:fail
popd
echo.
pause
exit /b 1
