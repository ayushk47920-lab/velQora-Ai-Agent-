# VelQora Workflow

This page follows one request from the browser to the finished briefing. File names refer to this repository.

## 1. User workflow (three pages)

1. **Page 1 — `frontend/pages/index.html`.** The user enters the company or person (required), an optional website or
   LinkedIn URL, the meeting time and the meeting purpose, then presses *Start Research*. `assets/js/research.js`
   saves the entries in `sessionStorage` (`vq.handoff`) and opens Page 2. If browser storage is blocked, an error is
   shown and the flow stops — there is no second research path. The animated demo on the page is cosmetic.
2. **Page 2 — `research-setup.html`.** `assets/js/setup.js` restores the entries, lets the user set the research query
   and depth (`quick` / `standard` / `deep`) and sends **one** `POST /api/research`. It then opens Page 3 with the
   returned job ID. Returning to Page 2 can continue the saved job instead of submitting again.
3. **Page 3 — `research-results.html?id=<research_id>`.** `assets/js/research-results.js` reads the ID from the URL,
   polls `GET /api/research/{id}` until the job is `completed` or `failed`, then fetches
   `GET /api/briefing/{briefing_id}` and renders the saved report. A refresh resumes by ID; Page 3 never starts new
   research and handles pending, failed, missing and network-error states.

`briefing.html?id=<briefing_id>` shows the same briefing as the original one-page printable layout.

## 2. How the frontend communicates with the backend

All requests go through `VQApi` in `assets/js/api.js` (JSON, 30 s default timeout, Bearer token when signed in, no
credentials/cookies). The base URL is empty (same origin) when FastAPI serves the pages on port 8000, otherwise
`http://localhost:8000` on localhost, or `window.VELQORA_API_BASE` if set. Errors from the backend arrive as
`{error:{code,message}}` and are shown as readable messages. No API keys exist in the frontend.

## 3. How AI research is processed (backend job)

`POST /api/research` validates the body (Pydantic), checks that `TAVILY_API_KEY` is set, stores a `research` row and
starts a background task, then immediately answers `202`. The task (`services/research_service.py`) reports these stages
while the browser polls:

| Stage | What happens |
|---|---|
| `validating` | Input already validated; entity (company/person, domain) is built |
| `searching` | `agents/research_agent.py` builds a bounded search plan for the chosen depth and calls Tavily (up to 3 searches in parallel). `quick` = 2 basic searches, `standard` = 4 basic searches, `deep` = 6 advanced searches, all capped by `TAVILY_MAX_SEARCHES_PER_RESEARCH`. Only the news search is restricted to the 30-day window. If some searches fail they are skipped with a warning; if all fail the real error is returned. |
| `processing` | Results are normalised, cleaned (HTML stripped, instruction-like text removed), de-duplicated, ranked and trimmed to `MAX_SOURCES` |
| `date_validation` | Each source is classified `in_window`, `out_of_window` or `undated` (Tavily `published_date`, with a strict `/YYYY/MM/DD/` URL fallback) |
| `analyzing` | `agents/analysis_agent.py` sends the cleaned source text to Bifrost in **one** model request (plus a retry only if the reply is not valid JSON) and asks for structured JSON. If Bifrost is not configured or fails, the briefing continues without AI analysis and says so in `warnings`. |
| `verifying` | Claims are mapped to sources and checked (next section) |
| `preparing` | `agents/briefing_agent.py` assembles the report; it is validated against the Pydantic `Briefing` model and saved |
| `completed` / `failed` | Final state; a failure carries `error: {code, message}` |

## 4. How source verification works

Implemented in `services/claim_mapping_service.py` and `services/source_verification_service.py`. It is
deterministic and uses no LLM tokens.

1. Factual statements from the AI analysis (overview, products, people, recent developments, news, competitors,
   industry…) become *claims* with the source IDs the model cited. IDs that are not real sources are dropped and a
   warning is added.
2. Each claim is compared with every retrieved source's text: numbers, proper names and substantive key words must
   appear in the source. A match on the company name alone never counts. `VERIFY_MIN_OVERLAP` (default 0.6) sets how
   much key-word overlap is required.
3. The result is one evidence state per claim: `supported`, `partially_supported`, `conflicting`, `unsupported`,
   `unverified` or `outdated`. Conflicting evidence (for example a negation or a different figure in another source) is
   reported explicitly.
4. Time-sensitive claims (the *recent developments* section, or wording such as "currently" or "latest") are fully
   supported only when a supporting source has a reliable date inside the 30-day window. Otherwise they are labelled
   `undated` or `outdated` and shown under "Not confirmed as recent".
5. Only fully supported, in-window claims enter the verified fact sections. Everything else is listed separately.
   AI-written talking points, questions, risks and opportunities are always labelled as analysis.

These labels describe text matching against retrieved snippets. They do not prove a publisher is reliable.

## 5. How the final briefing is generated

When verification finishes, `BriefingService` builds the briefing JSON (summary, key findings, people, developments,
news, products, competitors, industry, talking points, questions, risks, opportunities, open questions, undated and
unverified items, sources with their supporting claims, a verification summary, AI info and warnings), validates it
against `Briefing`, and stores it in the `briefings` table. The research row receives `briefing_id`, status
`completed`, and the sources now carry their verification evidence. Page 3 then renders it from
`GET /api/briefing/{id}`, keeping Tavily's original URL on every source.

If research was started with `auto_brief=false`, or a briefing needs to be re-run, `POST /api/briefing/generate`
creates one from the finished research (idempotent unless `force` is set).

## 6. Failure behaviour

| Situation | Result |
|---|---|
| No `TAVILY_API_KEY` | `503 tavily_not_configured` on `POST /api/research` |
| Tavily key rejected / quota / rate limit / daily cap | Job `failed` with `tavily_*` error code |
| Bifrost not configured, unreachable, rejected, rate limited, or the model reply is not valid JSON after retries | Briefing completes **without** AI analysis; `warnings` contains `AI analysis unavailable: <reason>` |
| No relevant sources | Report states that no analysis was attempted; gaps appear as open questions |
| Server restarted mid-job | Job is marked `failed` on next start (not resumed) |
