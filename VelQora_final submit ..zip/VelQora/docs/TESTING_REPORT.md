# VelQora Testing Report

This report separates what was **actually executed** during the organization of the project from what **could not be
executed** in that environment. Nothing below is claimed as passed unless it was run and passed.

**Environment used for verification:** Linux sandbox, Python 3.12.3, Node.js v22.23.4, PyJWT 2.7.0 and python-dotenv /
python-dateutil installed, **no network access**. `fastapi`, `uvicorn`, `pydantic`, `httpx` and `pytest` were **not
installed and could not be installed** there.

## 1. Executed and passed

### 1.1 Frontend workflow tests — `node --test frontend/tests/workflow.test.cjs` → **9 passed, 0 failed**

| # | Test |
|---|---|
| 1 | Page 1 hands all four details to Page 2 and does not submit research |
| 2 | Page 1 stops safely when session storage is unavailable |
| 3 | Page 2 submits one request with setup details, then opens that job on Page 3 |
| 4 | Page 2 resumes a saved job without another research submission |
| 5 | Page 3 refreshes the URL job, renders real response data and does not POST |
| 6 | Page 3 renders the API response when browser storage is blocked |
| 7 | Page 3 reports missing jobs and backend errors without starting research |
| 8 | Page 3 resumes queued work, and handles failed jobs and missing briefing IDs |
| 9 | The same browser session carries one research_id from Page 1 through Page 3 |

These tests use mocked browser objects and mocked API responses.

### 1.2 Backend tests that do not need FastAPI — **58 test cases passed, 0 failed, 1 skipped**

`pytest` itself could not be installed, so these test modules were executed with a **small throw-away stand-in for
`pytest`** (it only implements `raises`, `mark.parametrize` and `importorskip`) and a plain Python runner. The test code
and the application code were run unmodified. This is real execution of the project's tests, but it is **not** a
`pytest` run; please re-run `pytest -q` on your machine (see section 3).

| Test file | Result |
|---|---|
| `tests/test_source_verification.py` | 11 passed |
| `tests/test_research.py` | 31 passed (19 test functions; one is parametrized into 13 cases) |
| `tests/test_briefing.py` | 16 passed, 1 skipped (`test_briefing_matches_pydantic_schema` needs `pydantic`) |

Covered: URL validation / SSRF blocking, date parsing and the 30-day window, source normalisation, de-duplication and
ranking, search plans per depth, Tavily request shape / cache / daily cap / retries / error mapping / health,
Bifrost request shape / auth modes / errors / health, JSON extraction, claim verification (supported, partial,
conflicting, unsupported, outdated), briefing assembly with and without an LLM, and invalid-JSON retries — all against
**fake Tavily and Bifrost transports**.

### 1.3 Configuration, database and security helpers (run directly)

| Check | Result |
|---|---|
| `backend/.env.example` loads through `Settings.from_env()`; placeholders mean Tavily/Bifrost report "not configured" | Passed |
| `frontend_dir` resolves to `<project>/frontend` (with `pages/` and `assets/`) when run from an unrelated working directory | Passed |
| Environment overrides applied; invalid integer falls back to the default; invalid auth mode falls back to `bearer` | Passed |
| SQLite file and parent folders are created; schema creates `users`, `research`, `briefings` (idempotent) | Passed |
| Repositories: create / get / update / JSON round-trip / `latest_for_research` / `fail_interrupted` | Passed |
| scrypt password hash + verify; JWT create / decode / rejection with a wrong secret (PyJWT 2.7.0 here; `requirements.txt` asks for ≥ 2.8) | Passed |

### 1.4 Static checks

| Check | Result |
|---|---|
| `node --check` on all 7 frontend scripts and the test file | Passed |
| Python syntax compile of all 45 backend files | Passed |
| Relative-import resolution across `backend/` (every `from .x import y` target exists) | 0 problems |
| Third-party imports (`fastapi`, `starlette`, `pydantic`, `httpx`, `dotenv`, `dateutil`, `jwt`, `pytest`) are covered by `requirements.txt` (`starlette` comes with FastAPI) | Passed |
| HTML `href`/`src` references, resolved against the URL layout FastAPI serves (`/assets`, `/pages`) | 57 checked, 0 broken |
| Page names used in JavaScript navigation (`index`, `research-setup`, `research-results`, `briefing`) exist | Passed |
| API paths called by `frontend/assets/js/api.js` have matching route declarations in `backend/app/api/routes/` (string-level check) | 9 of 9 present |
| Markdown relative links and anchors in the README and docs | Passed |
| No key-like strings; no `.env`, `.db`, `.pyc` or log files in the package | Passed |
| Application code unchanged: `backend/app`, `backend/tests`, `frontend/assets`, `frontend/pages`, `frontend/tests` and `requirements.txt` are byte-identical to the uploaded project | Confirmed with `diff` |

### 1.5 Startup scripts

| Check | Result |
|---|---|
| `bash -n scripts/run_linux_mac.sh` (syntax) | Passed |
| Real run without network: fails with the clear message "could not install dependencies" and exit code 1, as designed | Passed |
| Run with a stubbed virtual-environment interpreter: creates `backend/.env` from `.env.example` (no keys written), prints notes for the blank `TAVILY_API_KEY` / `BIFROST_MODEL`, starts `uvicorn app.main:app --host 127.0.0.1 --port 8000` from `backend/` — also when launched from a different directory; prints no notes when both values are set | Passed |

## 2. Not executed (could not be run here)

| Item | Why |
|---|---|
| `backend/tests/test_health.py` (11 tests: the full pipeline over HTTP via `TestClient`, health endpoints, request validation, auth and job ownership, rate limiting, CORS and security headers) | Needs FastAPI/Starlette/httpx |
| The pydantic-based schema test and Pydantic request validation of the real endpoints | `pydantic` not installed |
| Starting the real server (`uvicorn`), FastAPI serving `frontend/` at `/` and `/pages/…`, and opening the pages in a browser (no existing test covers the static mount; only the path layout was checked, see 1.4) | FastAPI/uvicorn not installed; no browser session |
| `scripts/run_windows.bat` | No Windows environment. It was written carefully (CRLF line endings, ASCII only) but has **not** been run |
| `scripts/run_linux_mac.sh` on macOS | Only tested on Linux |
| A real `pip install -r requirements.txt` | No network access |
| **Live integration tests**: real Tavily search, real Bifrost + LLM call, `GET /api/health/services?deep=true`, a real end-to-end research | No API credentials and no network. All Tavily/Bifrost behaviour above was exercised only through fake transports |

## 3. How to complete the verification on your machine

```bash
# 1. Backend: full suite, including test_health.py
cd backend
python -m venv .venv && source .venv/bin/activate      # Windows: .venv\Scripts\activate
pip install -r requirements.txt
pytest -q

# 2. Frontend
cd ../frontend && node --test tests/workflow.test.cjs

# 3. Start the app and check the wiring (needs your keys in backend/.env)
cd .. && ./scripts/run_linux_mac.sh                    # Windows: scripts\run_windows.bat
curl http://localhost:8000/api/health
curl http://localhost:8000/api/health/services          # live Tavily / Bifrost status
```

Local tests (everything with fake transports) and live integration tests (real Tavily/Bifrost) are different things:
passing the local tests does not prove that your keys, your Bifrost provider or your model id are correct — only
`/api/health/services` and a real research run do.

## 4. History

`docs/archive/PHASE5_WORKFLOW_AUDIT.md` is the earlier audit that came with the uploaded project. It records that the
backend tests had not been run in that environment either.
