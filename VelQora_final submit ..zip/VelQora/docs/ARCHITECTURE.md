# VelQora Architecture

## 1. System overview

VelQora is a two-part application:

- a **static frontend** (HTML/CSS/vanilla JS) — no framework, no build step;
- a **FastAPI backend** that runs research jobs, calls two external services (Tavily and Bifrost), verifies claims
  and stores everything in **SQLite**.

In the default setup FastAPI serves the frontend too, so the browser talks to one origin: `http://localhost:8000`.

```
┌──────────────┐   HTTP/JSON    ┌──────────────────────────── FastAPI (backend/app) ───────────────────────────┐
│   Browser    │ ─────────────► │ routes (api/routes)  →  ResearchService (job lifecycle)                       │
│ frontend/    │ ◄───────────── │      │                       │                                                │
│ pages+assets │   polling      │      │                       ├─► ResearchAgent ─► TavilyService ─► Tavily API │
└──────────────┘                │      ▼                       ├─► BriefingService                               │
                                │  SQLite repositories         │     ├─ AnalysisAgent ─► BifrostService ─► Bifrost ─► LLM
                                │  (users, research, briefings)│     ├─ claim mapping + source verification    │
                                │                              │     └─ BriefingAgent → Pydantic `Briefing`    │
                                └──────────────────────────────┴────────────────────────────────────────────────┘
```

## 2. Main components

### Frontend (`frontend/`)

| Component | Responsibility |
|---|---|
| `assets/js/api.js` | The only API client (`VQApi`): timeouts, error normalisation, Bearer token, base-URL selection |
| `assets/js/auth.js` | Sign-in/up form logic, token storage, nav link |
| `assets/js/research.js` | Page 1: validates the entry and hands it to Page 2 via `sessionStorage` (`vq.handoff`) |
| `assets/js/setup.js` | Page 2: form, the single `POST /api/research`, saved-job resume |
| `assets/js/research-results.js` | Page 3: polls the job, fetches the briefing, renders the report |
| `assets/js/briefing.js` | Cards and the standalone printable `briefing.html` |
| `assets/js/app.js` | Shared helpers (escaping), original parallax/scroll code |
| `assets/css/*.css` | Original stylesheet split into files, plus `setup.css` and `research-results.css` |

### Backend (`backend/app/`)

| Module | Responsibility |
|---|---|
| `main.py` | App factory: error handlers, CORS, security headers, routers, static frontend mount |
| `config.py` | `Settings` read from environment variables / `backend/.env` |
| `dependencies.py` | Dependency container, in-memory rate limiter, optional-auth dependencies |
| `api/routes/` | `health`, `research`, `briefing`, `auth` endpoints |
| `services/research_service.py` | Job lifecycle: create → research → briefing; progress updates; restart recovery |
| `agents/research_agent.py` | Builds the bounded Tavily search plan per depth; normalises, de-duplicates, ranks sources |
| `services/tavily_service.py` | Tavily client: retries, in-process cache, daily call cap, `/usage` health check |
| `agents/analysis_agent.py` + `agents/prompts.py` | Builds the prompt from sources and asks the model for structured JSON |
| `services/bifrost_service.py` | Bifrost (OpenAI-compatible) client: auth modes, fallback model, retries, health check |
| `services/claim_mapping_service.py`, `services/source_verification_service.py` | Map claims to sources and verify them by text grounding |
| `agents/verification_agent.py` | Thin compatibility façade over the verification services |
| `agents/briefing_agent.py` | Assembles the final briefing structure |
| `schemas/` | Pydantic request/response and briefing models |
| `database/` | SQLite connection and repositories |
| `utils/` | URL/name validation, date window logic, source cleaning/ranking |
| `security.py` | scrypt password hashing, JWT create/decode |
| `exceptions.py` | Error classes that map to the `{error:{code,message}}` format |

## 3. Technology relationships

- **FastAPI/Starlette** serves the API and the static frontend; **Pydantic** validates every request and the final briefing.
- **httpx** is the HTTP client behind a small transport layer (`services/http_client.py`), which is what the tests replace.
- **Tavily** supplies web results; **Bifrost** is the gateway to whichever LLM provider you configure. The model name is
  configuration (`BIFROST_MODEL`), not code.
- **python-dotenv** loads `backend/.env`; **PyJWT** signs tokens; **SQLite** (`sqlite3`) stores data.

## 4. API communication flow

1. Browser → `POST /api/research` → backend validates, stores a `research` row, starts a background task and answers
   `202` with the job.
2. Browser → `GET /api/research/{id}` repeatedly → backend returns status, stage, progress, sources and `briefing_id`.
3. Browser → `GET /api/briefing/{briefing_id}` → backend returns status and, when completed, the briefing JSON.
4. During the job the backend calls Tavily (`POST /search`) and Bifrost (`POST /v1/chat/completions`).

Details per stage: [WORKFLOW.md](WORKFLOW.md). Endpoint contracts: [API_DOCUMENTATION.md](API_DOCUMENTATION.md).

## 5. Database interaction

SQLite file `backend/velqora.db` (override with `DATABASE_PATH`; created automatically on startup, git-ignored).
Three tables, created with `CREATE TABLE IF NOT EXISTS` in `database/models.py`:

| Table | Purpose |
|---|---|
| `users` | Optional accounts: id, unique email, name, scrypt password hash, created_at |
| `research` | One row per research job: status, stage, progress, message, request/entity/window/sources/warnings/error JSON, `briefing_id`, timestamps |
| `briefings` | One row per generated briefing: `research_id`, status, stage, progress, `briefing_json`, `error_json`, timestamps (index on `research_id`) |

All access goes through repository classes, so the rest of the code never touches `sqlite3` directly. On startup,
jobs left `queued`/`running` by a previous process are marked `failed`.

## 6. Concurrency and limits

Jobs run as asyncio tasks inside the server process, limited by `MAX_CONCURRENT_JOBS` (default 3). Rate limits, the
Tavily cache and the daily Tavily call counter are in memory, so they reset on restart and are per process.
