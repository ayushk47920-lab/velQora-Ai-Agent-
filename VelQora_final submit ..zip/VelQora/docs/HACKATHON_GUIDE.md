# VelQora Hackathon Guide

## 1. Before the demo (about the environment, not performance)

**Required software**

- Python 3.10+ (the startup scripts check this)
- A browser (any modern one)
- A Tavily API key (<https://app.tavily.com>)
- A running Bifrost gateway with one LLM provider key added in Bifrost (needs Node.js **or** Docker)
- Node.js — only if you want to show the frontend tests

**Configuration checklist**

1. Start Bifrost (`npx -y @maximhq/bifrost` or `docker run -p 8080:8080 maximhq/bifrost`) and add a provider in its UI
   at <http://localhost:8080>.
2. `curl http://localhost:8080/v1/models` and copy the exact model id.
3. Run `./scripts/run_linux_mac.sh` (or `scripts\run_windows.bat`) once; it creates `backend/.env` from the template.
4. Edit `backend/.env`: set `TAVILY_API_KEY`, `BIFROST_BASE_URL`, `BIFROST_MODEL` (and `BIFROST_API_KEY` only if your
   Bifrost requires one). Restart the script.
5. Open <http://localhost:8000/api/health/services>. Tavily and Bifrost should both report `"status":"ok"`.
   Anything else tells you what is missing (`not_configured`, `auth_failed`, `unreachable`, `degraded`…).

**Mind your credits.** Each research uses Tavily credits (`quick` ≤ 2, `standard` ≤ 4, `deep` ≤ 12) and one model call.
The default limit is 12 research starts per hour per IP. Do not burn them on practice runs right before the demo;
identical searches are cached for 6 hours.

## 2. Recommended demonstration sequence

1. **The problem (30 s):** meeting prep is slow and AI summaries state unsupported claims confidently.
2. **Page 1 (landing):** enter a real company, optionally its website, a meeting time and a purpose. Press *Start Research*.
3. **Page 2 (setup):** show the research query and the three depths (`quick`, `standard`, `deep`); pick one and submit
   once. Mention that the form protects against double submission.
4. **Page 3 (report):** watch the server-reported progress stages, then walk through the report: key findings, recent
   developments, key people, source cards (original URL, domain, date, snippet).
5. **Trust labels:** show a *verified* item with its source IDs, then an item under *Not confirmed as recent* or
   *unverified*, and the AI-analysis items that are labelled as analysis.
6. **Refresh Page 3** to show it resumes by research ID without starting new research.
7. **Behind the scenes (optional):** `/api/docs` (Swagger UI), `/api/health/services`, and the tests
   (`pytest -q`, `node --test tests/workflow.test.cjs`).

## 3. Features worth showing judges

- Source-grounded verification: every factual claim is checked against retrieved text; nothing is silently trusted.
- Honest failure modes: missing keys, quota limits and AI downtime are reported, never faked.
- 30-day recency window with explicit *undated / outdated* handling.
- Bounded, credit-aware research (depth modes, caps, cache, daily call cap).
- Security basics: no keys in the frontend, URL validation, untrusted-web-text handling, output escaping, rate limits.
- The model is configuration only — change `BIFROST_MODEL`, not code.

## 4. If keys or network are unavailable during the demo

You can still show: Page 1 → Page 2 flow, `/api/health/services` reporting what is not configured, the Swagger UI,
the code structure, and both test suites. Do not present a briefing as live research unless it came from real Tavily
and Bifrost calls.

## 5. Common errors and troubleshooting

| Symptom | Fix |
|---|---|
| UI says the backend isn't reachable | Start the backend (the startup script); if the frontend is on another port add that origin to `CORS_ORIGINS`. Keep the backend on port **8000**. |
| `503 tavily_not_configured` | Set `TAVILY_API_KEY` in `backend/.env`, restart |
| `tavily_auth_failed` / quota messages | Key wrong, or free credits used up (check `/api/health/services`) |
| Brief says *AI analysis unavailable* (the reason follows in the warning) | Check `/api/health/services`: is Bifrost running, is a provider key added in Bifrost, is `BIFROST_MODEL` the exact id from `/v1/models`? |
| Warning mentions a bad request or unknown model | Model id wrong or provider not configured in Bifrost |
| Warning mentions authentication | Bifrost enforces auth: set `BIFROST_API_KEY` (and `BIFROST_AUTH_MODE=virtual_key` if it uses virtual keys) |
| Warning says the model did not return valid JSON | Model too weak for JSON output; pick another, or set `BIFROST_JSON_MODE=true` if your provider supports it |
| Many claims "unverified" | Sources are short snippets; try `deep` mode, or open the linked sources to check the wording |
| "No dated developments" | Little recent coverage, or sources lack publication dates (they are listed as undated, not hidden) |
| Rate-limit message | Wait, or raise `RESEARCH_RATE_LIMIT_PER_HOUR` (each research costs Tavily credits) |
| Windows: *Python was not found* / Microsoft Store opens | Install Python from python.org with "Add to PATH"; turn off the python.exe App execution alias in Windows settings |
| Script: *could not install dependencies* | Check your internet connection and run the script again |
| Logins reset after restart | `JWT_SECRET` is blank, so a temporary secret is generated each start; set a long random value |
