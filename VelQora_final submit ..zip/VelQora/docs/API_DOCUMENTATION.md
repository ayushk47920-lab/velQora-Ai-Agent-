# VelQora API Documentation

Base URL (local): `http://localhost:8000`. All endpoints are under `/api`. Interactive Swagger UI is available at
`/api/docs` (disabled when `APP_ENV=production`). Requests and responses are JSON. Responses from `/api/*` carry
`Cache-Control: no-store`.

> The definitive contract is the Pydantic models in `backend/app/schemas/` and the routes in
> `backend/app/api/routes/`. This page describes them; it does not add behaviour.

## Authentication

Authentication is **optional by default** (`REQUIRE_AUTH=false`). When a request carries
`Authorization: Bearer <token>`, research and briefings are owned by that user and are visible only to them.
Anonymous jobs are reachable by their unguessable 32-character hex ID. With `REQUIRE_AUTH=true`, starting or
reading research without a valid token returns `401 unauthorized`.

## Error format

Every error uses one shape:

```json
{ "error": { "code": "validation_error", "message": "Human readable text", "details": [ { "field": "name", "message": "…" } ] } }
```

`details` is optional. Rate-limit responses also send a `Retry-After` header.

| HTTP | `code` | Meaning |
|---|---|---|
| 401 | `unauthorized`, `invalid_credentials` | Missing/invalid token or wrong email/password |
| 404 | `not_found` | Unknown or not-visible research/briefing, or unknown path |
| 409 | `email_taken`, `research_not_ready`, `research_failed` | Conflict (see endpoint notes) |
| 422 | `validation_error` | Request body/path failed validation |
| 429 | `rate_limited` | Per-IP rate limit (general or research) |
| 503 | `tavily_not_configured`, `service_not_configured` | Required service key/config missing |
| 500 | `internal_error` | Unexpected server error (details never leaked) |

**Tavily problems inside a running job** are stored on the job and returned by the polling endpoints as
`status: "failed"` with an `error: {code, message}` object — the polling request itself still succeeds. Codes:
`tavily_auth_failed`, `tavily_quota_exceeded`, `tavily_rate_limited`, `tavily_daily_cap`, `tavily_bad_request`,
`tavily_bad_response`, `tavily_error`, `tavily_unreachable`, and `internal_error` for unexpected failures.
A failed search only fails the job when **every** search failed; otherwise the failed searches are skipped and listed in `warnings`.

**Bifrost / model problems do not fail the job.** If the AI gateway is not configured, unreachable, rejects the request,
is rate limited or returns invalid JSON, the briefing still completes without AI analysis and `warnings` contains
`"AI analysis unavailable: <reason>"` (`briefing.ai.analysis_available` is `false`). The underlying codes
(`bifrost_not_configured`, `bifrost_auth_failed`, `bifrost_rate_limited`, `bifrost_bad_request`, `bifrost_bad_response`,
`bifrost_empty_response`, `bifrost_unreachable`, `bifrost_error`, `llm_invalid_json`) are used inside the backend; use
`GET /api/health/services` to diagnose the gateway.

---

## Health

### `GET /api/health`
Backend is up. → `200 {"status":"ok","service":"velqora-backend","version":"1.0.0","time":"<UTC ISO time>"}`

### `GET /api/health/services[?deep=true]`
Configuration and connectivity of FastAPI, Tavily and Bifrost. Secrets are never returned.

- Tavily is checked through its `/usage` endpoint (does not consume search credits).
- Bifrost is checked through its `/health` endpoint, then the configured model is looked up in `/v1/models`.
  `?deep=true` additionally makes a tiny model completion (uses a few tokens).

→ `200 {"status":"ok"|"degraded","services":{"fastapi":{…},"tavily":{…},"bifrost":{…}},"attention":["tavily",…]}`

Per-service `status` values include `ok`, `not_configured`, `unreachable`, `timeout`, `auth_failed`, `degraded`, `error`.
A missing key therefore shows as `not_configured` instead of failing.

---

## Research

### `POST /api/research`
Validate the input and start an asynchronous research job (rate limited per IP; defaults: 60 requests/min general,
12 research starts/hour). Unknown fields are rejected.

Request body:

| Field | Type | Required | Notes |
|---|---|---|---|
| `name` | string | yes | Company or person |
| `url` | string | no | Website or LinkedIn URL (http/https; private/loopback hosts rejected) |
| `meeting_time` | string | no | Free text, ≤ 80 chars |
| `purpose` | string | no | ≤ 200 chars |
| `research_query` | string | no | Focused question, ≤ 200 chars (defaults to `name`) |
| `research_depth` | `quick` \| `standard` \| `deep` | no | Default `standard` |
| `entity_type` | `auto` \| `company` \| `person` | no | Default `auto` |
| `auto_brief` | boolean | no | Default `true`: generate the briefing when research finishes |

→ `202 ResearchStatus`. Errors: `422 validation_error`, `503 tavily_not_configured` (no `TAVILY_API_KEY`),
`429 rate_limited`, `401 unauthorized` (only if `REQUIRE_AUTH=true`).

### `GET /api/research/{research_id}`
`research_id` must match `^[a-f0-9]{32}$`. → `200 ResearchStatus`, or `404 not_found`.

`ResearchStatus`:

```json
{
  "research_id": "…", "status": "queued|running|completed|failed",
  "stage": "validating|searching|processing|date_validation|analyzing|verifying|preparing|completed|failed",
  "progress": 0, "message": "…",
  "entity": {"name": "…", "type": "…", "website": "…", "linkedin_url": "…"},
  "research_query": "…", "research_depth": "standard",
  "research_period": {"start_date": "YYYY-MM-DD", "end_date": "YYYY-MM-DD"},
  "created_at": "…", "updated_at": "…",
  "briefing_id": "… or null", "sources_count": 0, "sources": [ … ],
  "warnings": [ … ], "error": null
}
```

---

## Briefing

### `POST /api/briefing/generate`
Body: `{"research_id": "<32 hex>", "force": false}`. Generates a briefing from finished research. Idempotent: if a
queued/running/completed briefing already exists it is returned with `200` unless `force` is `true` (which re-runs the
model, uses tokens and shares the research rate limit). A new briefing is started with `202`.

Errors: `404 not_found`, `409 research_not_ready` (research still running), `409 research_failed`.

### `GET /api/briefing/{briefing_id}`
→ `200 BriefingStatus`: `{briefing_id, research_id, status, stage, progress, message, created_at, updated_at, briefing, error}`.
`briefing` is `null` until `status` is `completed`.

### Briefing JSON (`briefing`)

Defined by `Briefing` in `backend/app/schemas/briefing_schema.py`. Main fields: `research_id`, `briefing_id`,
`research_query`, `research_depth`, `generated_at`, `entity`, `research_period`, `meeting`, `overview`,
`executive_summary`, `executive_summary_items`, `key_findings`, `claim_mappings`, `overview_items`, `key_people`,
`recent_developments`, `important_news`, `business_insights`, `products_services`, `competitor_analysis`,
`industry_information`, `industry_tags`, `limitations`, `missing_information`, `meeting_talking_points`,
`suggested_questions`, `potential_risks`, `opportunities`, `open_questions`, `undated_information`,
`unverified_claims`, `sources`, `verification_summary`, `ai` (`analysis_available`, `model`), `warnings`.

- Each item (`BriefingItem`) has `kind` (`fact` / `analysis` / `unavailable`), `verification_status`, optional
  `confidence_status`, and `source_ids` that always reference a source included in the same report.
- Each source (`BriefingSource`) keeps Tavily's original `url`, plus `domain`, `publisher`, `published_date`,
  `date_status` (`in_window` / `out_of_window` / `undated`), `retrieved_at`, `snippet`, the claims it supports /
  partially supports / conflicts with, and `verification_status`.
- Each claim mapping has `claim_id`, `section`, `finding`, `explanation`, `kind` and its source IDs and confidence status.
- Claim evidence states: `supported`, `partially_supported`, `conflicting`, `unsupported`, `unverified`, `outdated`.
  Only fully supported, in-window claims enter verified fact sections.

---

## Auth (optional accounts)

| Endpoint | Body | Response |
|---|---|---|
| `POST /api/auth/register` | `{"email","password" (8–128 chars),"name"?}` | `201 {access_token, expires_in, user}`; `409 email_taken` |
| `POST /api/auth/login` | `{"email","password"}` | `200 {access_token, expires_in, user}`; `401 invalid_credentials` |
| `GET /api/auth/me` | — (Bearer token) | `200 {id,email,name}`; `401 unauthorized` |

Passwords are hashed with scrypt; tokens are HS256 JWTs signed with `JWT_SECRET` (default lifetime 24 h,
`JWT_EXPIRE_MINUTES`).

---

## Examples

```bash
curl -X POST localhost:8000/api/research -H 'Content-Type: application/json' \
  -d '{"name":"Aurelia Systems","research_query":"Assess its recent logistics product launches","research_depth":"standard","url":"aurelia.com","meeting_time":"Fri 14 Nov 11:00","purpose":"Investor meeting"}'

curl localhost:8000/api/research/<research_id>
curl localhost:8000/api/briefing/<briefing_id>
curl 'localhost:8000/api/health/services'
```

(`Aurelia Systems` is an example name only; real research requires your Tavily key.)
