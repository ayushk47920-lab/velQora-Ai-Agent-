"""Source records, claim mapping, citation safety, and evidence-status coverage."""
from app.services.claim_mapping_service import map_claims
from app.services.source_service import prepare_sources
from app.services.source_verification_service import verify_claims


def _source(source_id="S1", *, url="https://example.com/story?utm_source=test", title="Aurelia Systems update",
            content="Aurelia Systems raised $40 million in Series B funding led by Northwind Capital.",
            published="2026-11-01", date_status="in_window"):
    return {
        "source_id": source_id, "title": title, "url": url, "content": content,
        "published_date": published, "date_status": date_status, "retrieved_at": "2026-11-13T09:00:00Z",
    }


def test_source_metadata_original_url_ids_and_duplicates():
    raw = [
        _source(url="https://www.example.com/story?utm_source=one", content="Aurelia Systems raised $40 million."),
        _source(url="https://example.com/story?utm_source=two", content="Aurelia Systems raised $40 million in Series B funding."),
        _source(url="https://example.com/other", title="Aurelia Systems market report", published=None),
    ]
    sources = prepare_sources(raw)
    assert len(sources) == 2
    assert [source["source_id"] for source in sources] == ["S1", "S2"]
    assert len({source["sourceId"] for source in sources}) == 2
    first = sources[0]
    assert first["original_url"] == "https://www.example.com/story?utm_source=one"
    assert first["url"] == first["original_url"]
    assert first["domain"] == "example.com" and first["publishedAt"] == "2026-11-01"
    assert first["retrievedAt"] and first["snippet"]
    assert sources[1]["published_date"] is None


def test_source_service_rejects_invalid_and_credential_urls():
    rows = [
        _source(url="javascript:alert(1)"),
        _source(url="ftp://example.com/file"),
        _source(url="http://127.0.0.1/private"),
        _source(url="https://user:password@example.com/story"),
        _source(url="https://example.com:8443/story"),
    ]
    assert prepare_sources(rows) == []


def test_claim_mapper_validates_ids_and_separates_interpretations():
    mapped = map_claims({
        "overview": [{"text": "Aurelia builds freight software. It serves logistics firms.",
                      "source_ids": ["S1", "S99", "S1"]}],
        "meeting_talking_points": [{"text": "Ask about the freight roadmap.", "basis_source_ids": ["S1"]}],
    }, [_source()])
    assert len(mapped["facts"]) == 2 and mapped["facts"][0]["sourceIds"] == ["S1"]
    assert mapped["invalid_source_ids"] == ["S99"]
    assert mapped["analysis"][0]["kind"] == "analysis"
    assert mapped["analysis"][0]["confidenceStatus"] == "unverified"


def test_supported_claim_citations_are_actual_sources():
    sources = [_source()]
    claim = {"claim_id": "C1", "section": "recent_developments", "text":
             "Aurelia Systems raised $40 million in Series B funding.", "source_ids": ["S1"]}
    result = verify_claims([claim], sources, 0.6)[0]
    assert result["confidenceStatus"] == "supported"
    assert result["sourceIds"] == ["S1"] and result["verification_status"] == "verified"
    assert set(result["sourceIds"]) <= {source["source_id"] for source in sources}
    assert sources[0]["supports_claims"] == ["C1"]


def test_name_only_match_is_not_evidence_and_invalid_id_is_not_cited():
    sources = [_source(content="Aurelia Systems is a company profile with general contact information.")]
    claim = {"claim_id": "C1", "section": "overview", "text":
             "Aurelia Systems acquired Nimbus Robotics for $900 million.", "source_ids": ["S999"]}
    result = verify_claims([claim], sources, 0.6)[0]
    assert result["confidenceStatus"] == "unverified"
    assert result["sourceIds"] == [] and result["invalid_source_ids"] == ["S999"]


def test_cited_but_irrelevant_source_is_unsupported():
    sources = [_source(content="Aurelia Systems publishes an overview of its company and contact information.")]
    claim = {"claim_id": "C2", "section": "overview", "text":
             "Aurelia Systems acquired Nimbus Robotics for $900 million.", "source_ids": ["S1"]}
    result = verify_claims([claim], sources, 0.6)[0]
    assert result["confidenceStatus"] == "unsupported"
    assert result["sourceIds"] == []


def test_numeric_disagreement_is_conflicting():
    sources = [_source()]
    claim = {"claim_id": "C3", "section": "business_insights", "text":
             "Aurelia Systems raised $90 million in Series B funding.", "source_ids": ["S1"]}
    result = verify_claims([claim], sources, 0.6)[0]
    assert result["confidenceStatus"] == "conflicting"
    assert result["sourceIds"] == ["S1"] and sources[0]["conflicts_with_claims"] == ["C3"]


def test_partial_support_is_not_promoted_to_supported():
    sources = [_source(content="Aurelia Systems provides freight logistics software for shipping companies.")]
    claim = {"claim_id": "C4", "section": "products_services", "text":
             "Aurelia Systems provides freight logistics software and airline analytics services.", "source_ids": ["S1"]}
    result = verify_claims([claim], sources, 0.6)[0]
    assert result["confidenceStatus"] == "partially_supported"
    assert result["verification_status"] == "partially_supported"
    assert result["sourceIds"] == ["S1"]


def test_partial_claim_can_reference_multiple_real_sources():
    sources = [
        _source("S1", content="Aurelia Systems sells freight software."),
        _source("S2", url="https://example.com/other", content="Aurelia Systems sells routing software."),
    ]
    claim = {"claim_id": "C7", "section": "products_services", "text":
             "Aurelia Systems sells freight routing software.", "source_ids": ["S1", "S2"]}
    result = verify_claims([claim], sources, 0.6)[0]
    assert result["confidenceStatus"] == "partially_supported"
    assert result["sourceIds"] == ["S1", "S2"]


def test_outdated_recent_claim_is_not_marked_supported():
    sources = [_source(content="Aurelia Systems opened a Singapore office.", published="2024-01-15",
                        date_status="out_of_window")]
    claim = {"claim_id": "C5", "section": "recent_developments", "text":
             "Aurelia Systems opened a Singapore office.", "source_ids": ["S1"]}
    result = verify_claims([claim], sources, 0.6)[0]
    assert result["confidenceStatus"] == "outdated"
    assert result["verification_status"] == "outdated"


def test_empty_sources_and_missing_publication_dates_are_safe():
    empty = verify_claims([{"claim_id": "C6", "section": "overview", "text": "A factual finding.", "source_ids": []}], [], 0.6)
    assert empty[0]["confidenceStatus"] == "unverified" and empty[0]["sourceIds"] == []
    sources = prepare_sources([_source(published=None, content="Aurelia Systems operates a freight software platform.")])
    assert sources[0]["publishedAt"] is None and sources[0]["retrievedAt"]
    assert verify_claims([], sources, 0.6) == []
