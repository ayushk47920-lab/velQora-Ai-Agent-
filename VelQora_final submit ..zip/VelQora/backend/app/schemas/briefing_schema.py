"""Structured briefing schema. Every AI-generated field is validated against these models."""
from __future__ import annotations

from typing import Any, Dict, List, Literal, Optional

from pydantic import BaseModel, ConfigDict, Field, model_validator

from .research_schema import ApiErrorInfo

ItemStatus = Literal["verified", "unverified", "undated", "outdated", "analysis", "unavailable",
                     "partially_supported", "conflicting"]
SourceStatus = Literal["verified", "unverified", "undated"]
ConfidenceStatus = Literal["supported", "partially_supported", "conflicting", "unsupported", "unverified", "outdated"]


class BriefingItem(BaseModel):
    """One statement. kind: fact (checked against sources) | analysis (AI-generated) | unavailable (gap)."""
    claim_id: Optional[str] = None
    text: str
    kind: Literal["fact", "analysis", "unavailable"]
    verification_status: ItemStatus
    confidence_status: Optional[ConfidenceStatus] = None
    source_ids: List[str] = Field(default_factory=list)
    date: Optional[str] = None
    origin: Optional[str] = None
    note: Optional[str] = None
    explanation: Optional[str] = None


class KeyPerson(BaseModel):
    name: str
    role: str = ""
    claim_id: Optional[str] = None
    source_ids: List[str] = Field(default_factory=list)
    verification_status: ItemStatus = "verified"
    confidence_status: ConfidenceStatus = "supported"


class BriefingEntity(BaseModel):
    name: str
    type: Literal["company", "person", "unknown"] = "unknown"
    website: Optional[str] = None
    linkedin_url: Optional[str] = None


class ResearchPeriod(BaseModel):
    start_date: str
    end_date: str


class MeetingInfo(BaseModel):
    purpose: Optional[str] = None
    time: Optional[str] = None
    time_iso: Optional[str] = None


class BriefingSource(BaseModel):
    source_id: str
    sourceId: Optional[str] = None
    title: str
    url: str
    normalized_url: Optional[str] = None
    domain: str = ""
    publisher: str
    published_date: Optional[str] = None
    publishedAt: Optional[str] = None
    date_status: Literal["in_window", "out_of_window", "undated"]
    date_source: Optional[str] = None
    retrieved_at: str
    retrievedAt: Optional[str] = None
    source_type: str
    excerpt: str = ""
    snippet: str = ""
    supports_claims: List[str] = Field(default_factory=list)
    partially_supports_claims: List[str] = Field(default_factory=list)
    conflicts_with_claims: List[str] = Field(default_factory=list)
    evidence_status: Literal["supporting", "partial", "conflicting", "mixed", "uncited"] = "uncited"
    verification_status: SourceStatus = "unverified"
    age_label: str = ""


class VerificationSummary(BaseModel):
    verified_claims: int = 0
    unverified_claims: int = 0
    undated_claims: int = 0
    total_claims: int = 0
    partially_supported: int = 0
    conflicting: int = 0
    unsupported: int = 0
    unverified: int = 0
    outdated: int = 0


class ClaimMapping(BaseModel):
    claim_id: str
    section: str
    finding: str
    sourceIds: List[str] = Field(default_factory=list)
    confidenceStatus: ConfidenceStatus = "unverified"
    explanation: str = ""
    kind: Literal["fact", "analysis"] = "fact"


class AiInfo(BaseModel):
    analysis_available: bool = False
    model: Optional[str] = None


class Briefing(BaseModel):
    model_config = ConfigDict(extra="ignore")

    research_id: str
    briefing_id: str
    research_query: str = ""
    research_depth: Literal["quick", "standard", "deep"] = "standard"
    status: Literal["completed"] = "completed"
    generated_at: str
    entity: BriefingEntity
    research_period: ResearchPeriod
    meeting: MeetingInfo = Field(default_factory=MeetingInfo)
    overview: str = ""
    executive_summary: str = ""
    executive_summary_items: List[BriefingItem] = Field(default_factory=list)
    key_findings: List[BriefingItem] = Field(default_factory=list)
    claim_mappings: List[ClaimMapping] = Field(default_factory=list)
    overview_items: List[BriefingItem] = Field(default_factory=list)
    key_people: List[KeyPerson] = Field(default_factory=list)
    recent_developments: List[BriefingItem] = Field(default_factory=list)
    important_news: List[BriefingItem] = Field(default_factory=list)
    business_insights: List[BriefingItem] = Field(default_factory=list)
    products_services: List[BriefingItem] = Field(default_factory=list)
    competitor_analysis: List[BriefingItem] = Field(default_factory=list)
    industry_information: List[BriefingItem] = Field(default_factory=list)
    industry_tags: List[str] = Field(default_factory=list)
    limitations: List[str] = Field(default_factory=list)
    missing_information: List[BriefingItem] = Field(default_factory=list)
    meeting_talking_points: List[BriefingItem] = Field(default_factory=list)
    suggested_questions: List[BriefingItem] = Field(default_factory=list)
    potential_risks: List[BriefingItem] = Field(default_factory=list)
    opportunities: List[BriefingItem] = Field(default_factory=list)
    open_questions: List[BriefingItem] = Field(default_factory=list)
    undated_information: List[BriefingItem] = Field(default_factory=list)
    unverified_claims: List[BriefingItem] = Field(default_factory=list)
    sources: List[BriefingSource] = Field(default_factory=list)
    verification_summary: VerificationSummary = Field(default_factory=VerificationSummary)
    ai: AiInfo = Field(default_factory=AiInfo)
    warnings: List[str] = Field(default_factory=list)

    @model_validator(mode="after")
    def citations_reference_returned_sources(self):
        source_ids = [source.source_id for source in self.sources]
        if len(source_ids) != len(set(source_ids)):
            raise ValueError("Source IDs must be unique within a report.")
        if any(source.sourceId and source.sourceId != source.source_id for source in self.sources):
            raise ValueError("Source ID aliases must match the report source ID.")
        valid = set(source_ids)
        referenced = set()
        for field_name in (
            "executive_summary_items", "key_findings", "overview_items", "recent_developments", "important_news", "business_insights",
            "products_services", "competitor_analysis", "industry_information", "missing_information",
            "meeting_talking_points", "suggested_questions", "potential_risks", "opportunities", "open_questions",
            "undated_information", "unverified_claims",
        ):
            for item in getattr(self, field_name):
                referenced.update(item.source_ids)
        for person in self.key_people:
            referenced.update(person.source_ids)
        for mapping in self.claim_mappings:
            referenced.update(mapping.sourceIds)
        invalid = referenced - valid
        if invalid:
            raise ValueError("Claim citations must reference a source included in the report.")
        return self


class BriefingGenerateRequest(BaseModel):
    model_config = ConfigDict(extra="forbid")

    research_id: str = Field(..., pattern=r"^[a-f0-9]{32}$")
    force: bool = Field(False, description="Regenerate even if a briefing already exists (uses LLM tokens)")


class BriefingStatusResponse(BaseModel):
    briefing_id: str
    research_id: str
    status: Literal["queued", "running", "completed", "failed"]
    stage: str
    progress: int = Field(ge=0, le=100)
    message: str = ""
    created_at: str
    updated_at: str
    briefing: Optional[Briefing] = None
    error: Optional[ApiErrorInfo] = None
