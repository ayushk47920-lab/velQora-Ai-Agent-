"""Evidence-safe mapping of factual findings and AI interpretations to real source IDs."""
from __future__ import annotations

import re
from typing import Any, Dict, Iterable, List, Set

FACT_SECTIONS = (
    "overview", "products_services", "competitor_analysis", "key_people", "recent_developments",
    "business_insights", "industry_information",
)
ANALYSIS_SECTIONS = (
    "meeting_talking_points", "suggested_questions", "potential_risks", "opportunities", "open_questions",
)


def _list(value: Any) -> list:
    if value is None:
        return []
    if isinstance(value, (list, tuple)):
        return list(value)
    return [value]


def _ids(value: Any, valid: Set[str] | None) -> tuple[List[str], List[str]]:
    values = _list(value)
    if len(values) == 1 and isinstance(values[0], str) and re.search(r"[,;\s]", values[0]):
        values = [part.strip("[](){}'\"") for part in re.split(r"[,;\s]+", values[0]) if part.strip("[](){}'\"")]
    accepted: List[str] = []
    invalid: List[str] = []
    for value in values:
        source_id = str(value).strip().strip("[]")
        if not source_id:
            continue
        if valid is None or source_id in valid:
            if source_id not in accepted:
                accepted.append(source_id)
        elif source_id not in invalid:
            invalid.append(source_id)
    return accepted, invalid


def _sentences(text: str) -> List[str]:
    """Split multi-sentence AI findings so each factual statement gets its own mapping."""
    return [part.strip() for part in re.split(r"(?<=[.!?])\s+(?=[A-Z0-9])", text) if len(part.strip()) >= 2]


def map_claims(analysis: Dict[str, Any] | None, sources: Iterable[dict] | None = None) -> dict:
    """Return individually mapped facts and separately labelled AI analysis.

    Only source IDs present in `sources` survive mapping. The verifier later selects IDs
    whose content actually supports, partially supports, or contradicts each finding.
    """
    source_rows = [item for item in (sources or []) if isinstance(item, dict)]
    valid_ids = None if sources is None else {
        str(item.get("source_id") or item.get("sourceId")) for item in source_rows
        if item.get("source_id") or item.get("sourceId")
    }
    invalid_ids: List[str] = []
    facts: List[dict] = []
    analysis_items: List[dict] = []
    raw = analysis if isinstance(analysis, dict) else {}

    for section in FACT_SECTIONS:
        for item in _list(raw.get(section)):
            if not isinstance(item, dict):
                continue
            name = str(item.get("name") or "").strip() if section == "key_people" else ""
            role = str(item.get("role") or "").strip() if section == "key_people" else ""
            finding = (f"{name}, {role}" if name and role else name) if section == "key_people" else str(
                item.get("text") or item.get("claim") or item.get("statement") or "").strip()
            findings = [finding] if section == "key_people" else _sentences(finding)
            if not findings or len(finding) < 2:
                continue
            ids, invalid = _ids(item.get("source_ids") or item.get("sources") or [], valid_ids)
            invalid_ids.extend(invalid)
            for sentence in findings:
                claim_id = f"C{len(facts) + 1}"
                facts.append({
                    "claim_id": claim_id, "section": section, "kind": "fact", "finding": sentence,
                    "text": sentence, "sourceIds": ids, "source_ids": ids,
                    "confidenceStatus": "unverified", "confidence_status": "unverified",
                    "explanation": "Evidence comparison has not run.", "name": name or None, "role": role,
                    "invalid_source_ids": invalid,
                })

    for section in ANALYSIS_SECTIONS:
        for item in _list(raw.get(section)):
            if isinstance(item, str):
                finding, raw_ids = item.strip(), []
            elif isinstance(item, dict):
                finding = str(item.get("text") or item.get("question") or "").strip()
                raw_ids = item.get("source_ids") or item.get("basis_source_ids") or []
            else:
                continue
            if len(finding) < 2:
                continue
            ids, invalid = _ids(raw_ids, valid_ids)
            invalid_ids.extend(invalid)
            analysis_items.append({
                "claim_id": f"A{len(analysis_items) + 1}", "section": section, "kind": "analysis",
                "finding": finding, "text": finding, "sourceIds": ids, "source_ids": ids,
                "confidenceStatus": "unverified", "confidence_status": "unverified",
                "explanation": "AI-generated interpretation or suggestion; not treated as a verified fact.",
            })

    return {"facts": facts, "analysis": analysis_items, "invalid_source_ids": list(dict.fromkeys(invalid_ids))}


class ClaimMappingService:
    def map(self, analysis: Dict[str, Any] | None, sources: Iterable[dict] | None = None) -> dict:
        return map_claims(analysis, sources)
