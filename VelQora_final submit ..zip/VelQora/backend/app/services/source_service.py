"""Source record validation, normalization, de-duplication, and API metadata."""
from __future__ import annotations

import re
from typing import Iterable, List, Optional
from urllib.parse import urlsplit

from ..utils.date_utils import utc_now_iso
from ..utils.source_utils import domain_of, normalize_url, publisher_from_domain
from ..utils.validation import sanitize_text


def _safe_original_url(value: object) -> Optional[tuple[str, str]]:
    original = value.strip() if isinstance(value, str) else ""
    normalized = normalize_url(original)
    if not normalized:
        return None
    try:
        parts = urlsplit(original)
        port = parts.port
    except ValueError:
        return None
    if parts.username or parts.password or port not in (None, 80, 443):
        return None
    return original, normalized


def _merge_duplicate(current: dict, incoming: dict) -> dict:
    current_date = bool(current.get("published_date"))
    incoming_date = bool(incoming.get("published_date"))
    current_score = current.get("score") if isinstance(current.get("score"), (int, float)) else 0
    incoming_score = incoming.get("score") if isinstance(incoming.get("score"), (int, float)) else 0
    chosen = incoming if (incoming_date, incoming_score) > (current_date, current_score) else current
    merged = dict(chosen)
    merged["categories"] = list(dict.fromkeys((current.get("categories") or []) + (incoming.get("categories") or [])))
    if len(str(current.get("content") or "")) > len(str(merged.get("content") or "")):
        merged["content"] = current["content"]
    return merged


def prepare_sources(items: Iterable[dict]) -> List[dict]:
    """Return safe, unique sources with stable report-scoped IDs and compatibility aliases.

    `url` and `original_url` preserve the returned citation target. `normalized_url` is
    retained separately for safe URL matching and duplicate detection.
    """
    retrieved_at = utc_now_iso()
    by_url: dict[str, dict] = {}
    for raw in items or []:
        if not isinstance(raw, dict):
            continue
        checked = _safe_original_url(raw.get("original_url") or raw.get("url"))
        if not checked:
            continue
        original_url, normalized_url = checked
        domain = domain_of(normalized_url)
        title = sanitize_text(raw.get("title"), 220) or domain
        content = sanitize_text(raw.get("content") or raw.get("snippet") or raw.get("excerpt"), 1200)
        published = raw.get("published_date") or raw.get("publishedAt") or raw.get("published_at")
        if not isinstance(published, str) or not published.strip():
            published = None
        source = dict(raw)
        source.update({
            "title": title,
            "url": original_url,
            "normalized_url": normalized_url,
            "original_url": original_url,
            "domain": domain,
            "publisher": sanitize_text(raw.get("publisher"), 120) or publisher_from_domain(domain),
            "published_date": published.strip() if published else None,
            "retrieved_at": raw.get("retrieved_at") or raw.get("retrievedAt") or retrieved_at,
            "content": content,
            "snippet": content[:300],
        })
        existing = by_url.get(normalized_url)
        by_url[normalized_url] = _merge_duplicate(existing, source) if existing else source

    # Keep the source engine's secondary same-publisher/title de-duplication behavior.
    unique: List[dict] = []
    seen_titles: set[tuple[str, str]] = set()
    for source in by_url.values():
        title_key = re.sub(r"\W+", " ", source["title"].lower()).strip()
        signature = (source["domain"], title_key)
        if signature in seen_titles:
            continue
        seen_titles.add(signature)
        unique.append(source)

    for index, source in enumerate(unique, start=1):
        source_id = f"S{index}"
        source["source_id"] = source_id
        source["sourceId"] = source_id
        source["publishedAt"] = source.get("published_date")
        source["retrievedAt"] = source["retrieved_at"]
    return unique


class SourceService:
    """Small stateless façade used by the existing research pipeline."""

    def prepare(self, sources: Iterable[dict]) -> List[dict]:
        return prepare_sources(sources)
