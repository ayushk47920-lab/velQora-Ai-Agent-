"""Deterministic comparison of factual claims against retrieved source content.

Statuses describe textual evidence coverage, not whether a publisher or statement is
objectively true. A source is never considered supporting based on a company-name match alone.
"""
from __future__ import annotations

import re
from typing import Dict, Iterable, List, Optional, Set, Tuple

from ..utils.date_utils import IN_WINDOW, UNDATED

VERIFIED, UNVERIFIED, UNDATED_STATUS, OUTDATED = "verified", "unverified", "undated", "outdated"
SUPPORTED = "supported"
PARTIALLY_SUPPORTED = "partially_supported"
CONFLICTING = "conflicting"
UNSUPPORTED = "unsupported"
UNVERIFIED_STATUS = "unverified"
OUTDATED_STATUS = "outdated"
CONFIDENCE_STATUSES = {
    SUPPORTED, PARTIALLY_SUPPORTED, CONFLICTING, UNSUPPORTED, UNVERIFIED_STATUS, OUTDATED_STATUS,
}
_UNITS_AND_GENERIC = {
    "company", "companies", "business", "million", "billion", "trillion", "percent", "percentage",
    "usd", "dollar", "dollars", "rupee", "rupees", "eur", "gbp", "year", "years", "month", "months",
    "quarter", "quarters", "day", "days", "week", "weeks", "employee", "employees", "people", "compani", "employe",
}
_NEGATIVE = re.compile(
    r"\b(?:did\s+not|does\s+not|do\s+not|has\s+not|have\s+not|had\s+not|was\s+not|were\s+not|"
    r"is\s+not|are\s+not|never|denied|denies|without|no\s+longer|failed\s+to)\b", re.I,
)
_TIME_SENSITIVE = re.compile(r"\b(current|currently|latest|recent|today|now|this year|last week|last month)\b", re.I)
_SENTENCE_SPLIT = re.compile(r"(?<=[.!?])\s+(?=[A-Z0-9])")
_STOP = set("""a an the and or but if then than that this these those of in on at to for from by with without into over under
about as is are was were be been being has have had do does did will would can could should may might must it its their
his her our your they them he she we you i not no yes also more most other some such only own same so very just
new said says say one two per via after before during between within up down out off again further once here there
when where why how all any both each few many much which who whom whose what while""".split())
_MONTHS = set("""january february march april may june july august september october november december jan feb mar apr jun
jul aug sep sept oct nov dec monday tuesday wednesday thursday friday saturday sunday""".split())
_NUM = re.compile(r"\d[\d,]*(?:\.\d+)?")


def stem(word: str) -> str:
    word = word.lower()
    if len(word) > 4 and word.endswith("ies"):
        word = word[:-3] + "y"
    elif len(word) > 5 and word.endswith("ing"):
        word = word[:-3]
    elif len(word) > 4 and word.endswith("ed"):
        word = word[:-2]
    elif len(word) > 4 and word.endswith("es"):
        word = word[:-2]
    elif len(word) > 3 and word.endswith("s") and not word.endswith("ss"):
        word = word[:-1]
    if len(word) > 4 and word.endswith("e"):
        word = word[:-1]
    return word


def _words(text: str) -> List[str]:
    return re.findall(r"[a-z]+", text.lower())


def numbers_in(text: str) -> Set[str]:
    return {number.replace(",", "").rstrip(".") for number in _NUM.findall(text)}


def content_stems(text: str) -> List[str]:
    return [stem(word) for word in _words(text) if word not in _STOP and word not in _MONTHS and len(word) > 2]


def proper_nouns(text: str) -> List[str]:
    tokens = re.findall(r"[A-Za-z][A-Za-z'’\-]*", text)
    out = []
    for index, token in enumerate(tokens):
        if index == 0 or not token[0].isupper() or token.isupper():
            continue
        lower = token.lower()
        if lower not in _STOP and lower not in _MONTHS:
            out.append(stem(lower.replace("'s", "").replace("’s", "")))
    return out


def ground(claim_text: str, source_text: str, min_overlap: float,
           extra_nouns: Optional[List[str]] = None) -> Tuple[bool, dict]:
    source_stems = set(stem(word) for word in _words(source_text))
    source_numbers = numbers_in(source_text)
    claim_numbers = numbers_in(claim_text)
    missing_numbers = sorted(number for number in claim_numbers if number not in source_numbers)
    nouns = proper_nouns(claim_text) + [stem(noun) for noun in (extra_nouns or [])]
    nouns = list(dict.fromkeys(nouns))
    found_nouns = [noun for noun in nouns if noun in source_stems]
    noun_ratio = len(found_nouns) / len(nouns) if nouns else 1.0
    words = list(dict.fromkeys(content_stems(claim_text)))
    overlap = sum(1 for word in words if word in source_stems) / len(words) if words else 0.0
    ok = not missing_numbers and noun_ratio >= 0.75 and overlap >= min_overlap and len(words) >= 2
    return ok, {"missing_numbers": missing_numbers, "noun_ratio": round(noun_ratio, 2), "overlap": round(overlap, 2)}


def _source_text(source: dict) -> str:
    body = source.get("content") or source.get("snippet") or source.get("excerpt") or ""
    return f'{source.get("title", "")}. {body}'


def _verify_person(claim: dict, source: dict, min_overlap: float) -> Tuple[bool, dict]:
    text = _source_text(source)
    name_ok, name_detail = ground(claim["name"], text, 0.0,
                                  re.findall(r"[A-Za-z][A-Za-z'’\-]*", claim["name"]))
    if not name_ok and name_detail["noun_ratio"] < 1.0:
        return False, name_detail
    role = claim.get("role", "")
    if not role:
        return True, name_detail
    role_stems = list(dict.fromkeys(content_stems(role)))
    source_stems = set(stem(word) for word in _words(text))
    share = sum(1 for word in role_stems if word in source_stems) / len(role_stems) if role_stems else 1.0
    detail = {"missing_numbers": [], "noun_ratio": name_detail["noun_ratio"], "overlap": round(share, 2)}
    return share >= 0.99, detail


def _ids(claim: dict) -> List[str]:
    raw = claim.get("sourceIds", claim.get("source_ids", [])) or []
    if isinstance(raw, str):
        raw = re.findall(r"\[?[A-Za-z]*\d+\]?", raw)
    values = [str(value).strip().strip("[]") for value in raw if value is not None]
    return list(dict.fromkeys(value for value in values if value))


def _anchor_terms(text: str) -> List[str]:
    """Return substantive lower-case terms, excluding named entities and generic units."""
    terms: List[str] = []
    for token in re.findall(r"[A-Za-z][A-Za-z'’\-]*", text):
        if token[0].isupper():
            continue
        for stem in content_stems(token):
            if stem not in _UNITS_AND_GENERIC and stem not in terms:
                terms.append(stem)
    return terms


def _anchor_match(claim: str, evidence: str) -> tuple[List[str], List[str], float]:
    anchors = _anchor_terms(claim)
    source_terms = set(content_stems(evidence))
    matched = [term for term in anchors if term in source_terms]
    ratio = len(matched) / len(anchors) if anchors else 0.0
    return anchors, matched, ratio


def _enough_detail(claim: str, evidence: str, anchors: List[str], matched: List[str], ratio: float,
                   threshold: float) -> bool:
    if len(matched) >= 2 and ratio >= threshold:
        return True
    claim_numbers = numbers_in(claim)
    evidence_numbers = numbers_in(evidence)
    return len(anchors) == 1 and len(matched) == 1 and bool(claim_numbers) and claim_numbers <= evidence_numbers


def _evidence_sentences(source: dict) -> List[str]:
    text = _source_text(source)
    return [part for part in _SENTENCE_SPLIT.split(text) if part.strip()] or [text]


def _contradiction(claim: str, source: dict, min_overlap: float) -> tuple[bool, str]:
    claim_numbers = numbers_in(claim)
    claim_negative = bool(_NEGATIVE.search(claim))
    claim_anchors, _, _ = _anchor_match(claim, "")
    if not claim_anchors:
        return False, ""
    for sentence in _evidence_sentences(source):
        anchors, matched, ratio = _anchor_match(claim, sentence)
        enough_terms = len(matched) >= 2 and ratio >= max(0.4, min_overlap * 0.65)
        enough_numeric_detail = len(claim_anchors) == 1 and len(matched) == 1 and bool(claim_numbers)
        if not (enough_terms or enough_numeric_detail):
            continue
        sentence_numbers = numbers_in(sentence)
        if claim_numbers and sentence_numbers and not (claim_numbers & sentence_numbers):
            return True, (f"A source gives figure(s) {', '.join(sorted(sentence_numbers))} where the claim gives "
                          f"{', '.join(sorted(claim_numbers))} for closely matching terms.")
        sentence_negative = bool(_NEGATIVE.search(sentence))
        if claim_negative != sentence_negative:
            # Avoid treating “not only” as a negative statement.
            normalized = sentence.lower().replace("not only", "")
            sentence_negative = bool(_NEGATIVE.search(normalized))
            if claim_negative != sentence_negative:
                return True, "A source states the matching claim with opposite wording or polarity."
    return False, ""


def _compare(claim: dict, source: dict, min_overlap: float) -> dict:
    finding = str(claim.get("finding") or claim.get("text") or "").strip()
    source_text = _source_text(source)
    anchors, matched, anchor_ratio = _anchor_match(finding, source_text)
    if claim.get("section") == "key_people" and claim.get("name"):
        person_ok, detail = _verify_person(claim, source, min_overlap)
        supported = person_ok
    else:
        supported, detail = ground(finding, source_text, min_overlap)
        # Make sure a generic mention of the subject cannot pass as evidence.
        supported = supported and _enough_detail(finding, source_text, anchors, matched, anchor_ratio, 0.9)
    contradiction, contradiction_reason = _contradiction(finding, source, min_overlap)
    relevant = _enough_detail(finding, source_text, anchors, matched, anchor_ratio,
                               max(0.4, min_overlap * 0.5)) or contradiction
    return {
        "supported": supported, "relevant": relevant, "conflicting": contradiction,
        "overlap": detail.get("overlap", 0.0), "matched_terms": matched,
        "anchor_count": len(anchors), "anchor_ratio": round(anchor_ratio, 2),
        "reason": contradiction_reason,
    }


def verify_claim_record(claim: dict, sources: Iterable[dict], min_overlap: float = 0.6) -> dict:
    """Verify one claim and return only references to retrieved evidence records."""
    rows = [source for source in (sources or []) if isinstance(source, dict)]
    by_id: Dict[str, dict] = {}
    for source in rows:
        source_id = source.get("source_id") or source.get("sourceId")
        if source_id:
            by_id.setdefault(str(source_id), source)
    finding = str(claim.get("finding") or claim.get("text") or "").strip()
    claimed_ids = _ids(claim)
    valid_claimed = [source_id for source_id in claimed_ids if source_id in by_id]
    invalid_ids = [source_id for source_id in claimed_ids if source_id not in by_id]

    relevant: List[tuple[str, dict, dict]] = []
    for source_id, source in by_id.items():
        result = _compare(claim, source, min_overlap)
        if result["relevant"] or result["supported"] or result["conflicting"]:
            relevant.append((source_id, source, result))

    supporting = [source_id for source_id, _, result in relevant if result["supported"]]
    partial = [source_id for source_id, _, result in relevant
               if result["relevant"] and not result["supported"] and not result["conflicting"]]
    conflicts = [source_id for source_id, _, result in relevant if result["conflicting"]]
    evidence_ids = list(dict.fromkeys(supporting + partial + conflicts))

    if conflicts:
        confidence = CONFLICTING
        conflict_details = [result["reason"] for source_id, _, result in relevant
                            if source_id in conflicts and result.get("reason")]
        explanation = "Conflicting evidence was found in: " + ", ".join(conflicts) + "."
        if conflict_details:
            explanation += " " + " ".join(dict.fromkeys(conflict_details))
        if supporting:
            explanation += " Other source(s) support the claim: " + ", ".join(supporting) + "."
        legacy_status = "conflicting"
    elif supporting:
        date_statuses = [by_id[source_id].get("date_status") for source_id in supporting]
        in_window = any(status == IN_WINDOW for status in date_statuses)
        undated = any(status in (UNDATED, None) for status in date_statuses)
        time_sensitive = claim.get("section") == "recent_developments" or bool(_TIME_SENSITIVE.search(finding))
        if time_sensitive and not in_window:
            if undated or not date_statuses or not all(status == "out_of_window" for status in date_statuses):
                confidence, legacy_status = UNVERIFIED_STATUS, UNDATED_STATUS
                explanation = "The wording matches retrieved evidence, but its publication date is unavailable."
            else:
                confidence, legacy_status = OUTDATED_STATUS, OUTDATED
                explanation = "The wording matches evidence published outside the selected research period."
        else:
            confidence, legacy_status = SUPPORTED, VERIFIED
            explanation = "The claim matches substantive text in: " + ", ".join(supporting) + "."
    elif partial:
        confidence, legacy_status = PARTIALLY_SUPPORTED, "partially_supported"
        explanation = "Some substantive terms match, but the retrieved evidence does not establish the full claim: " + ", ".join(partial) + "."
    elif valid_claimed:
        confidence, legacy_status = UNSUPPORTED, UNVERIFIED
        explanation = "The cited source(s) do not substantiate the finding beyond a subject-name match."
        evidence_ids = []
    elif rows:
        confidence, legacy_status = UNVERIFIED_STATUS, UNVERIFIED
        explanation = "No valid, substantively matching source reference was available for this claim."
        evidence_ids = []
    else:
        confidence, legacy_status = UNVERIFIED_STATUS, UNVERIFIED
        explanation = "No source evidence was retrieved for comparison."
        evidence_ids = []

    output = dict(claim)
    output.update({
        "finding": finding, "text": finding, "sourceIds": evidence_ids, "source_ids": evidence_ids,
        "supporting_source_ids": supporting, "partially_supporting_source_ids": partial,
        "conflicting_source_ids": conflicts, "invalid_source_ids": invalid_ids,
        "confidenceStatus": confidence, "confidence_status": confidence,
        "verification_status": legacy_status, "explanation": explanation, "reason": explanation,
    })
    published = [by_id[source_id].get("published_date") or by_id[source_id].get("publishedAt")
                 for source_id in evidence_ids]
    output["date"] = next((value for value in published if value), None)
    return output


def verify_claims(claims: Iterable[dict], sources: Iterable[dict], min_overlap: float = 0.6) -> List[dict]:
    rows = [source for source in (sources or []) if isinstance(source, dict)]
    results = [verify_claim_record(claim, rows, min_overlap) for claim in (claims or []) if isinstance(claim, dict)]
    by_id = {str(source.get("source_id") or source.get("sourceId")): source for source in rows
             if source.get("source_id") or source.get("sourceId")}
    for source in rows:
        source["supports_claims"] = []
        source["partially_supports_claims"] = []
        source["conflicts_with_claims"] = []
    for result in results:
        claim_id = result.get("claim_id")
        for source_id in result.get("supporting_source_ids", []):
            if source_id in by_id and claim_id and claim_id not in by_id[source_id]["supports_claims"]:
                by_id[source_id]["supports_claims"].append(claim_id)
        for source_id in result.get("partially_supporting_source_ids", []):
            if source_id in by_id and claim_id and claim_id not in by_id[source_id]["partially_supports_claims"]:
                by_id[source_id]["partially_supports_claims"].append(claim_id)
        for source_id in result.get("conflicting_source_ids", []):
            if source_id in by_id and claim_id and claim_id not in by_id[source_id]["conflicts_with_claims"]:
                by_id[source_id]["conflicts_with_claims"].append(claim_id)
    for source in rows:
        supports = source["supports_claims"]
        partials = source["partially_supports_claims"]
        conflicts = source["conflicts_with_claims"]
        if supports and conflicts:
            source["evidence_status"] = "mixed"
        elif conflicts:
            source["evidence_status"] = "conflicting"
        elif supports:
            source["evidence_status"] = "supporting"
        elif partials:
            source["evidence_status"] = "partial"
        else:
            source["evidence_status"] = "uncited"
        source["verification_status"] = "verified" if supports else "unverified"
    return results


class SourceVerificationService:
    def __init__(self, min_overlap: float = 0.6):
        self.min_overlap = min_overlap

    def verify(self, claims: Iterable[dict], sources: Iterable[dict]) -> List[dict]:
        return verify_claims(claims, sources, self.min_overlap)
