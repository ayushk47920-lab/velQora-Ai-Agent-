"""Briefing service: runs analysis -> verification -> briefing assembly for a finished research run."""
from __future__ import annotations

import logging
from datetime import date
from typing import Awaitable, Callable, List, Optional, Tuple

from ..agents import briefing_agent
from ..agents.analysis_agent import run_analysis
from ..config import Settings
from ..exceptions import ExternalServiceError, ServiceNotConfigured
from ..schemas.briefing_schema import Briefing
from ..utils.validation import Entity
from .bifrost_service import BifrostService
from .claim_mapping_service import map_claims
from .source_verification_service import verify_claims

logger = logging.getLogger("velqora.briefing")

ProgressFn = Callable[[str, int, str], Awaitable[None]]


class BriefingService:
    def __init__(self, settings: Settings, bifrost: BifrostService):
        self.settings = settings
        self.bifrost = bifrost

    async def build(self, *, research_id: str, briefing_id: str, entity: Entity, window: Tuple[date, date],
                    sources: List[dict], warnings: List[str], on_progress: Optional[ProgressFn] = None,
                    research_query: str = "", research_depth: str = "standard") -> dict:
        notify = on_progress or _noop
        warnings = list(warnings)
        analysis: Optional[dict] = None
        model: Optional[str] = None

        if any(s.get("injection_flagged") for s in sources):
            warnings.append("Some web pages contained instruction-like text; it was removed and never followed.")

        if sources:
            await notify("analyzing", 60, "Mapping key people…")
            try:
                out = await run_analysis(entity, sources, window, self.bifrost, self.settings,
                                         research_query, research_depth)
                analysis, model = out["analysis"], out["model"]
            except (ExternalServiceError, ServiceNotConfigured) as exc:
                logger.warning("AI analysis unavailable: %s", exc.message)
                warnings.append(f"AI analysis unavailable: {exc.message}")
        else:
            warnings.append("No relevant sources were retrieved, so no analysis was attempted.")

        await notify("verifying", 82, "Verifying claims…")
        mapped = map_claims(analysis, sources)
        if mapped["invalid_source_ids"]:
            warnings.append("Some AI-provided source references were invalid and were excluded from the report.")
        verified = verify_claims(mapped["facts"], sources, self.settings.verify_min_overlap)
        claim_mappings = verified + mapped["analysis"]

        await notify("preparing", 92, "Preparing your brief…")
        draft = briefing_agent.build_briefing(
            research_id=research_id, briefing_id=briefing_id, entity=entity, window=window, sources=sources,
            analysis=analysis, verified=verified, model=model, warnings=warnings,
            research_query=research_query or entity.name, research_depth=research_depth,
            claim_mappings=claim_mappings)
        return Briefing.model_validate(draft).model_dump()      # schema-validated, consistent JSON


async def _noop(*_args) -> None:
    return None
