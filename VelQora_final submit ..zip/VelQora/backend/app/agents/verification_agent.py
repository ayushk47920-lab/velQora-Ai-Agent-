"""Backward-compatible agent façade for the dedicated source verification services."""
from __future__ import annotations

from typing import Dict, List

from ..services.claim_mapping_service import FACT_SECTIONS, map_claims
from ..services.source_verification_service import (
    OUTDATED, UNDATED_STATUS, UNVERIFIED, VERIFIED, _source_text, _verify_person,
    content_stems, ground, numbers_in, proper_nouns, stem, verify_claim_record, verify_claims,
)

RECENCY_SECTIONS = {"recent_developments"}


def make_claims(analysis: Dict) -> List[dict]:
    """Flatten factual findings using the dedicated claim mapping service."""
    return map_claims(analysis)["facts"]


def verify_claim(claim: dict, sources: Dict[str, dict], min_overlap: float) -> dict:
    """Preserve the previous dictionary-based entry point for existing callers."""
    values = sources.values() if isinstance(sources, dict) else sources
    return verify_claim_record(claim, values, min_overlap)


def verify_all(claims: List[dict], sources: List[dict], min_overlap: float) -> List[dict]:
    """Preserve the previous list-based entry point for existing callers."""
    return verify_claims(claims, sources, min_overlap)
