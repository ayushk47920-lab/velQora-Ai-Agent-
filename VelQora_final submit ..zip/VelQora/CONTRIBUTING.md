# Contributing to VelQora

Thanks for helping improve VelQora. These are lightweight guidelines for this repository.

## Setup

```bash
./scripts/run_linux_mac.sh      # Linux/macOS   (Windows: scripts\run_windows.bat)
```

or follow the manual steps in the [README](README.md#9-installation). Configuration lives in `backend/.env`
(copied from `backend/.env.example`).

## Before you open a pull request

1. Run the backend tests: `cd backend && pytest -q`
2. Run the frontend tests: `cd frontend && node --test tests/workflow.test.cjs`
3. Check that every HTML page still loads its CSS/JS and that links between pages work.
4. Update the documentation in `README.md` / `docs/` when behaviour, endpoints or configuration change.

## Guidelines

- **Never commit secrets.** No real API keys, passwords or JWT secrets; `.env` stays git-ignored and
  `backend/.env.example` contains placeholders only.
- **Keep the API contract stable.** Routes and response shapes in `backend/app/api/routes/` and
  `backend/app/schemas/` are consumed by `frontend/assets/js/api.js`; change both sides together and update
  `docs/API_DOCUMENTATION.md`.
- **No fake data.** Do not replace Tavily/Bifrost behaviour with mock responses in application code. Mocks belong in tests only.
- **Keep the verification honest.** Do not label a claim `verified` unless it is grounded in retrieved source text.
- **Frontend:** plain HTML/CSS/vanilla JS; escape every dynamic value before rendering (`esc` in `app.js`).
- **Backend:** keep services behind the existing repository/service layers; add a test for each behaviour change.
- Keep changes small and focused; match the existing naming (`snake_case` for Python, lowercase-hyphen names for
  frontend files).
