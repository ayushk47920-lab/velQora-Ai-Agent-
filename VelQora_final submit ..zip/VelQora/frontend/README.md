# VelQora frontend

Plain HTML + CSS + vanilla JavaScript (no framework, no build step).

* `pages/index.html` – the original landing page; its input card hands the user's details to Page 2.
* `pages/briefing.html` – original one-page briefing (printable).
* `pages/research-results.html` – Page 3 company intelligence report; continues the one job started on Page 2, shows server-reported progress, then displays the saved research and citations.
* `pages/signin.html` – optional sign in / create account.
* `assets/css/` – the original stylesheet split into `variables / global / animations / components / responsive`
  (same rules, same cascade order). Page-specific setup and evidence states live in `setup.css` and `research-results.css`.
* `assets/js/api.js` – the single API client. `auth.js` session + nav link. Page 1 hands off to Page 2; Page 2 submits once, then Page 3 polls that job and renders the report.
  `briefing.js` card + full-page rendering (everything escaped). `app.js` helpers + the original parallax/scroll code.
* Page 3 source cards preserve Tavily's returned URL and show the source domain, publication date when available,
  retrieval timestamp, snippet, and evidence relationship. Claim labels are source-text comparisons, not fact guarantees.

Serve it with FastAPI (recommended, see the root README) or any static server, e.g.
`python -m http.server 5500` from this folder, then open `/pages/index.html`.

What changed in `index.html` versus the original: the `<style>`/`<script>` blocks became files; the Sign In link points
to `signin.html`; each input gained a transparent real `<input>` laid over the original text span (the demo typing
still plays on load but never starts research); one hidden line for error messages was added.

## Phase 1 — three-page flow (Page 1 → Page 2 → Page 3)
* `pages/research-setup.html` (+ `assets/css/setup.css`, `assets/js/setup.js`) is Page 2, "Configure Your Research".
* `research.js` change (Page 1): *Start Research* with a real entry saves the inputs to `sessionStorage` and opens Page 2.
  If storage is blocked, the page shows an error and stops; it does not start a second research flow. The animated demo remains cosmetic.
* Page 2 uses the existing `VQApi` call only to start research; after the server returns a job ID it opens Page 3 immediately. Page 3 uses existing GET calls to check that same job and fetch its briefing. Refreshing Page 3 resumes by ID and does not submit a second research request.
  The setup form carries the company/person, research query, URL, meeting time and purpose, and submits the existing `research_query` and `research_depth` (`quick`, `standard`, `deep`) fields.
* State keys: `vq.handoff`, `vq.setup.form`, `vq.job`, `vq.result`. Page 2 links back to Page 1; Page 3 links back to setup and home. `briefing.html` remains available as the original one-page report.
* Originals of Phase 1 files are kept for reference in `../docs/archive/frontend_phase1_backup/`; the result page uses `assets/css/research-results.css` for its report and evidence states.

Run the mocked three-page workflow checks from this folder with `node --test tests/workflow.test.cjs`.
