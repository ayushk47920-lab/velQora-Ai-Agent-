const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
const vm = require('node:vm');

const assets = path.resolve(__dirname, '..', 'assets', 'js');

class Element {
  constructor(value = '') {
    this.value = value;
    this.hidden = false;
    this.disabled = false;
    this.textContent = '';
    this.className = '';
    this.style = {};
    this.attributes = {};
    this.listeners = {};
    this.classes = new Set();
    this.classList = {
      add: name => this.classes.add(name),
      remove: name => this.classes.delete(name),
      contains: name => this.classes.has(name),
      toggle: (name, force) => {
        const enabled = force === undefined ? !this.classes.has(name) : force;
        enabled ? this.classes.add(name) : this.classes.delete(name);
        return enabled;
      },
    };
    this.firstChild = { textContent: '' };
  }
  addEventListener(name, fn) { (this.listeners[name] ||= []).push(fn); }
  dispatch(name, event = {}) {
    for (const fn of this.listeners[name] || []) fn({ preventDefault() {}, ...event });
  }
  setAttribute(name, value) { this.attributes[name] = value; }
  removeAttribute(name) { delete this.attributes[name]; }
  closest() { return this.field; }
  querySelector(selector) { return this.children?.[selector] || null; }
  focus() { this.focused = true; }
  appendChild(child) { (this.children ||= []).push(child); }
  remove() { this.removed = true; }
}

function memoryStorage(seed = {}, { failRead = false, failWrite = false } = {}) {
  const values = new Map(Object.entries(seed));
  return {
    getItem(key) { if (failRead) throw new Error('storage unavailable'); return values.get(key) ?? null; },
    setItem(key, value) { if (failWrite) throw new Error('storage unavailable'); values.set(key, String(value)); },
    removeItem(key) { if (failWrite) throw new Error('storage unavailable'); values.delete(key); },
    values,
  };
}

function runScript(name, context) {
  const source = fs.readFileSync(path.join(assets, name), 'utf8');
  vm.runInNewContext(source, context, { filename: name });
}

function pageOneContext({ storage = memoryStorage(), inputValues = ['', '', '', ''] } = {}) {
  const selectors = new Map();
  const ids = ['i1', 'i2', 'i3', 'i4', 't1', 't2', 't3', 't4', 'f1', 'f2', 'f3', 'f4',
    'goBtn', 'prog', 'statusTxt', 'badge', 'vqMsg'];
  ids.forEach(id => selectors.set(`#${id}`, new Element()));
  ['i1', 'i2', 'i3', 'i4'].forEach((id, i) => { selectors.get(`#${id}`).value = inputValues[i]; });
  selectors.get('#prog').querySelector = () => new Element();
  const destinations = [];
  const location = {};
  Object.defineProperty(location, 'href', { set: value => destinations.push(value), get: () => '' });
  const context = {
    $: selector => selectors.get(selector) || null,
    $$: () => [],
    sessionStorage: storage,
    location,
    document: { activeElement: null, createElement: () => new Element() },
    VelQora: { renderIdle() {} },
    VQApi: { health: () => Promise.resolve({}) },
    reduce: true,
    sleep: () => Promise.resolve(),
    setTimeout: () => 0,
    console: { error() {} },
    Date,
    Event: class Event {},
  };
  runScript('research.js', context);
  return { selectors, destinations, storage };
}

function fieldInput(value = '') {
  const input = new Element(value);
  const error = new Element();
  const field = new Element();
  field.children = { '.serr': error };
  input.field = field;
  return { input, error, field };
}

function futureDate(days = 7) {
  const d = new Date();
  d.setDate(d.getDate() + days);
  const pad = n => String(n).padStart(2, '0');
  return `${d.getFullYear()}-${pad(d.getMonth() + 1)}-${pad(d.getDate())}`;
}

function futureMeeting(days = 7) {
  const date = futureDate(days);
  const [year, month, day] = date.split('-').map(Number);
  const d = new Date(year, month - 1, day);
  const weekdays = ['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'];
  const months = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];
  return `${weekdays[d.getDay()]}, ${day} ${months[month - 1]} ${year} · 11:30`;
}

function pageTwoContext({ storage = memoryStorage({ 'vq.handoff': JSON.stringify({
  query: 'Assess recent product launches', url: 'https://aurelia.example', meeting_time: futureMeeting(), purpose: 'Partnership meeting',
}) }), startResearch = async () => ({ research_id: 'job-1' }) } = {}) {
  const selectors = new Map();
  const form = new Element();
  const fields = {
    q: fieldInput('Assess recent product launches'),
    c: fieldInput('Aurelia Systems'),
    d: fieldInput(futureDate()),
    t: fieldInput('11:30'),
    url: fieldInput('https://aurelia.example'),
    purpose: fieldInput('Partnership meeting'),
    depth: new Element('deep'),
  };
  const idMap = {
    '#setupForm': form, '#qInput': fields.q.input, '#cInput': fields.c.input,
    '#dInput': fields.d.input, '#tInput': fields.t.input, '#urlInput': fields.url.input,
    '#purposeInput': fields.purpose.input, '#depthInput': fields.depth,
    '#meetingTransferNote': new Element(), '#startBtn': new Element(), '#run': new Element(),
    '#runTxt': new Element(), '#runPct': new Element(), '#runBar': new Element(),
    '#setupMsg': new Element(), '#done': new Element(), '#doneLink': new Element(),
    '#backHome': new Element(),
  };
  Object.entries(idMap).forEach(([key, value]) => selectors.set(key, value));
  const navigations = [];
  const location = { assign: value => navigations.push(value) };
  const apiCalls = [];
  const api = {
    ApiError: class ApiError extends Error { constructor(status, code, message) { super(message); this.status = status; this.code = code; } },
    startResearch: payload => { apiCalls.push(payload); return startResearch(payload); },
  };
  const context = {
    $: selector => selectors.get(selector) || null,
    sessionStorage: storage,
    location,
    VQApi: api,
    console: { error() {} },
    Date,
    JSON,
    encodeURIComponent,
  };
  runScript('setup.js', context);
  return { selectors, fields, form, navigations, apiCalls, storage };
}

function reportFixture(researchId = 'job-real') {
  return {
    research_id: researchId,
    briefing_id: 'brief-real',
    status: 'completed',
    research_query: 'Assess recent product launches',
    research_depth: 'standard',
    completed_at: '2026-11-13T12:00:00Z',
    entity: { name: 'Aurelia Systems', type: 'Company', website: 'https://aurelia.example' },
    sources_count: 1,
  };
}

function briefingFixture(researchId = 'job-real') {
  return {
    research_id: researchId,
    status: 'completed',
    briefing: {
      research_query: 'Assess recent product launches',
      research_depth: 'standard',
      entity: { name: 'Aurelia Systems', type: 'Company', website: 'https://aurelia.example' },
      meeting: { time: 'Tue, 20 Nov 2026 · 11:30', purpose: 'Partnership meeting' },
      executive_summary: 'The company launched a new service.',
      key_findings: [{ text: 'The company launched a new service.', source_ids: ['SRC_1'], confidence_status: 'supported' }],
      sources: [{ source_id: 'SRC_1', title: 'Aurelia announcement', url: 'https://news.example/aurelia', domain: 'news.example', snippet: 'Aurelia launched a new service.', retrieved_at: '2026-11-13T11:00:00Z' }],
      verification_summary: { total_claims: 1, verified_claims: 1 },
    },
  };
}

function pageThreeContext({ id = 'job-real', storage = memoryStorage(), research = reportFixture(), briefing = briefingFixture(), researchError = null } = {}) {
  const root = new Element();
  const calls = { research: [], briefing: [], starts: 0 };
  const api = {
    ApiError: class ApiError extends Error { constructor(status, code, message) { super(message); this.status = status; this.code = code; } },
    getResearch: async value => {
      calls.research.push(value);
      if (researchError) throw researchError;
      return Array.isArray(research) ? research[Math.min(calls.research.length - 1, research.length - 1)] : research;
    },
    getBriefing: async value => { calls.briefing.push(value); return briefing; },
    startResearch: async () => { calls.starts += 1; throw new Error('Page 3 must not start research'); },
  };
  const context = {
    $: selector => selector === '#reportRoot' ? root : null,
    $$: () => [],
    esc: value => String(value ?? '').replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c])),
    sessionStorage: storage,
    location: { search: id ? `?id=${encodeURIComponent(id)}` : '' },
    URLSearchParams,
    VQApi: api,
    console: { error() {} },
    Date,
    URL,
    window: {},
    setTimeout: callback => { queueMicrotask(callback); return 0; },
  };
  runScript('research-results.js', context);
  return { root, calls, storage };
}

test('Page 1 hands all four details to Page 2 and does not submit research', async () => {
  const { selectors, destinations, storage } = pageOneContext({ inputValues: [
    'Aurelia Systems', 'https://aurelia.example', 'Tue, 20 Nov 2026 · 11:30', 'Partnership meeting',
  ] });
  await selectors.get('#goBtn').dispatch('click');
  assert.deepEqual(destinations, ['research-setup.html']);
  const handoff = JSON.parse(storage.getItem('vq.handoff'));
  assert.equal(handoff.query, 'Aurelia Systems');
  assert.equal(handoff.url, 'https://aurelia.example');
  assert.equal(handoff.meeting_time, 'Tue, 20 Nov 2026 · 11:30');
  assert.equal(handoff.purpose, 'Partnership meeting');
  assert.equal(typeof handoff.ts, 'number');
});

test('Page 1 stops safely when session storage is unavailable', async () => {
  const { selectors, destinations } = pageOneContext({ storage: memoryStorage({}, { failWrite: true }), inputValues: ['Aurelia', '', '', ''] });
  await selectors.get('#goBtn').dispatch('click');
  assert.deepEqual(destinations, []);
  assert.match(selectors.get('#vqMsg').textContent, /Research was not started/);
});

test('Page 2 submits one request with setup details, then opens that job on Page 3', async () => {
  let resolveRequest;
  const pending = new Promise(resolve => { resolveRequest = resolve; });
  const page = pageTwoContext({ startResearch: () => pending });
  page.fields.q.input.value = 'Assess recent product launches';
  page.fields.c.input.value = 'Aurelia Systems';
  const event = { preventDefault() {} };
  page.form.dispatch('submit', event);
  page.form.dispatch('submit', event);
  assert.equal(page.apiCalls.length, 1);
  resolveRequest({ research_id: 'job/a-1', status: 'queued' });
  await new Promise(resolve => setImmediate(resolve));
  assert.equal(page.navigations[0], 'research-results.html?id=job%2Fa-1');
  assert.equal(page.apiCalls[0].name, 'Aurelia Systems');
  assert.equal(page.apiCalls[0].research_query, 'Assess recent product launches');
  assert.equal(page.apiCalls[0].research_depth, 'deep');
  assert.equal(page.apiCalls[0].url, 'https://aurelia.example');
  assert.equal(page.apiCalls[0].purpose, 'Partnership meeting');
  assert.equal(page.apiCalls[0].auto_brief, true);
});

test('Page 2 resumes a saved job without another research submission', () => {
  const future = futureDate();
  const payload = { name: 'Aurelia Systems', research_query: 'Assess recent product launches', research_depth: 'standard',
    url: null, meeting_time: `Tue, 20 Nov 2026 · 11:30`, purpose: null, auto_brief: true };
  const signature = JSON.stringify(payload);
  const storage = memoryStorage({
    'vq.setup.form': JSON.stringify({ query: payload.research_query, company: payload.name, date: future, time: '11:30', depth: 'standard' }),
    'vq.job': JSON.stringify({ sig: signature, research_id: 'job-saved', status: 'running', payload }),
  });
  const page = pageTwoContext({ storage });
  assert.equal(page.apiCalls.length, 0);
  assert.equal(page.selectors.get('#done').hidden, false);
  assert.equal(page.selectors.get('#doneLink').href, 'research-results.html?id=job-saved');
});

test('Page 3 refreshes the URL job, renders real response data and does not POST', async () => {
  const old = { research_id: 'old-job', briefing: briefingFixture('old-job').briefing };
  const storage = memoryStorage({ 'vq.result': JSON.stringify(old) });
  const page = pageThreeContext({ storage });
  await new Promise(resolve => setImmediate(resolve));
  assert.deepEqual(page.calls.research, ['job-real']);
  assert.deepEqual(page.calls.briefing, ['brief-real']);
  assert.equal(page.calls.starts, 0);
  assert.match(page.root.innerHTML, /Aurelia Systems/);
  assert.match(page.root.innerHTML, /href="https:\/\/news\.example\/aurelia"/);
  assert.match(page.root.innerHTML, /#report-source-1/);
});

test('Page 3 renders the API response when browser storage is blocked', async () => {
  const page = pageThreeContext({ storage: memoryStorage({}, { failRead: true, failWrite: true }) });
  await new Promise(resolve => setImmediate(resolve));
  assert.match(page.root.innerHTML, /The company launched a new service/);
  assert.equal(page.calls.starts, 0);
});

test('Page 3 reports missing jobs and backend errors without starting research', async () => {
  const empty = pageThreeContext({ id: '' });
  await new Promise(resolve => setImmediate(resolve));
  assert.match(empty.root.innerHTML, /No research job found/);
  assert.equal(empty.calls.research.length, 0);

  const unavailable = pageThreeContext({ researchError: Object.assign(new Error('backend unavailable'), { status: 0, code: 'network' }) });
  await new Promise(resolve => setImmediate(resolve));
  assert.match(unavailable.root.innerHTML, /Unable to load the research report/);
  assert.equal(unavailable.calls.starts, 0);
});

test('Page 3 resumes queued work, and handles failed jobs and missing briefing IDs', async () => {
  const first = { ...reportFixture('job-queued'), briefing_id: undefined, status: 'queued', progress: 18, message: 'Searching sources' };
  const second = reportFixture('job-queued');
  const queued = pageThreeContext({ id: 'job-queued', research: [first, second], briefing: briefingFixture('job-queued') });
  await new Promise(resolve => setImmediate(resolve));
  assert.deepEqual(queued.calls.research, ['job-queued', 'job-queued']);
  assert.deepEqual(queued.calls.briefing, ['brief-real']);
  assert.match(queued.root.innerHTML, /Aurelia Systems/);

  const failed = pageThreeContext({ research: { ...reportFixture(), status: 'failed', message: 'Search provider unavailable', error: { message: 'Search provider unavailable' } } });
  await new Promise(resolve => setImmediate(resolve));
  assert.match(failed.root.innerHTML, /Research could not be completed/);
  assert.match(failed.root.innerHTML, /Search provider unavailable/);
  assert.equal(failed.calls.briefing.length, 0);

  const noBriefing = pageThreeContext({ research: { ...reportFixture(), briefing_id: undefined } });
  await new Promise(resolve => setImmediate(resolve));
  assert.match(noBriefing.root.innerHTML, /no report ID was returned/);
  assert.match(noBriefing.root.innerHTML, /Retry status check/);
  assert.equal(noBriefing.calls.briefing.length, 0);
});

test('the same browser session carries one research_id from Page 1 through Page 3', async () => {
  const storage = memoryStorage();
  const pageOne = pageOneContext({ storage, inputValues: [
    'Aurelia Systems', 'https://aurelia.example', futureMeeting(), 'Partnership meeting',
  ] });
  await pageOne.selectors.get('#goBtn').dispatch('click');
  assert.deepEqual(pageOne.destinations, ['research-setup.html']);

  let resolveRequest;
  const pending = new Promise(resolve => { resolveRequest = resolve; });
  const pageTwo = pageTwoContext({ storage, startResearch: () => pending });
  assert.equal(pageTwo.fields.c.input.value, 'Aurelia Systems');
  assert.equal(pageTwo.fields.url.input.value, 'https://aurelia.example');
  assert.equal(pageTwo.fields.purpose.input.value, 'Partnership meeting');
  pageTwo.fields.q.input.value = 'Assess recent product launches';
  pageTwo.form.dispatch('submit', { preventDefault() {} });
  resolveRequest({ research_id: 'job-flow-42', status: 'queued' });
  await new Promise(resolve => setImmediate(resolve));
  assert.deepEqual(pageTwo.navigations, ['research-results.html?id=job-flow-42']);

  const report = { ...reportFixture('job-flow-42'), briefing_id: 'brief-flow-42' };
  const briefing = { ...briefingFixture('job-flow-42'), briefing_id: 'brief-flow-42' };
  const pageThree = pageThreeContext({ id: 'job-flow-42', storage, research: report, briefing });
  await new Promise(resolve => setImmediate(resolve));
  assert.deepEqual(pageThree.calls.research, ['job-flow-42']);
  assert.deepEqual(pageThree.calls.briefing, ['brief-flow-42']);
  assert.equal(pageThree.calls.starts, 0);
  assert.match(pageThree.root.innerHTML, /Aurelia Systems/);
});
