/* ============================================================
   VelQora — Page 3: continue the single research job started from Page 2,
   show server-reported progress, then render the saved result without a second POST.
   ============================================================ */
(function(){
  const root=$("#reportRoot");
  if(!root) return;

  const KEY={handoff:"vq.handoff",draft:"vq.setup.form",job:"vq.job",result:"vq.result"};
  const read=k=>{try{return JSON.parse(sessionStorage.getItem(k)||"null");}catch(_){return null;}};
  const write=(k,v)=>{try{sessionStorage.setItem(k,JSON.stringify(v));}catch(_){}};
  const remove=k=>{try{sessionStorage.removeItem(k);}catch(_){}};
  const obj=v=>v&&typeof v==="object"&&!Array.isArray(v)?v:{};
  const arr=v=>Array.isArray(v)?v:[];
  const str=v=>typeof v==="string"&&v.trim()?v.trim():(typeof v==="number"&&Number.isFinite(v)?String(v):"");
  const href=v=>/^https?:\/\//i.test(String(v||""))?String(v):"";
  const listValues=(v)=>Array.isArray(v)?v:(typeof v==="string"&&v.trim()?[v]:[]);
  const escapeUrl=v=>esc(href(v));
  const handoff=obj(read(KEY.handoff)), draft=obj(read(KEY.draft));
  function state(title,message,kind="empty",onRetry=null){
    root.setAttribute("aria-busy","false");
    const failed=kind==="error";
    root.innerHTML=`<section class="report-state ${failed?"error-state":""}" role="status">
      <span class="state-mark ${failed?"failed":""}" aria-hidden="true">${failed?"!":"i"}</span>
      <p class="report-eyebrow state-eyebrow">${failed?"Research status":"Company intelligence"}</p>
      <h1>${esc(title)}</h1><p>${esc(message)}</p>
      <div class="state-actions">${onRetry?`<button class="btn btn-coral" id="retryStatus" type="button">Retry status check</button>`:""}<a class="btn ${onRetry?"btn-ghost":"btn-coral"}" href="research-setup.html">Return to research setup <span aria-hidden="true">→</span></a><a class="btn btn-ghost" href="index.html">Home</a></div>
    </section>`;
    const retry=$("#retryStatus"); if(retry&&onRetry)retry.addEventListener("click",onRetry);
  }

  function renderReport(report){
  const result=obj(report);
  const research=obj(result.research), briefing=obj(result.briefing);
  const hasResult=!!(result.research||result.briefing);
  const status=str(research.status)||"Status unavailable";
  const statusLower=status.toLowerCase();

  if(!hasResult){
    state("No saved report found","This page does not have a research job to continue. Return to setup and start a research request.");
    return;
  }
  if(statusLower==="failed"){
    const error=obj(research.error);
    state("Research did not complete",str(error.message)||str(research.message)||"The saved research job reported a failure. Return to setup to review it and retry if available.","error");
    return;
  }
  if(statusLower==="queued"||statusLower==="running"||statusLower==="in_progress"){
    const progress=Number(research.progress);
    const realProgress=Number.isFinite(progress)&&progress>=0&&progress<=100;
    state("Research is still in progress",`${str(research.message)||"The saved job has not reported completion yet."}${realProgress?` Current server-reported progress: ${Math.round(progress)}%.`:""} Return to setup to resume status checks.`,"empty");
    return;
  }
  if(!Object.keys(briefing).length){
    const error=obj(result.error);
    state("Research result is incomplete",str(error.message)||"The saved result does not contain a report to display. No additional research request was made.","error");
    return;
  }

  const entity=obj(briefing.entity), meeting=obj(briefing.meeting), period=obj(briefing.research_period), summary=obj(briefing.verification_summary), ai=obj(briefing.ai);
  const company=str(entity.name)||str(result.payload&&result.payload.name)||str(draft.company)||"Company name unavailable";
  const payload=obj(result.payload);
  const query=str(payload.research_query)||str(briefing.research_query)||str(result.original_query)||str(draft.query)||str(handoff.query)||"Not available in the saved setup";
  const researchDepth=str(briefing.research_depth)||str(result.payload&&result.payload.research_depth)||str(research.research_depth)||"standard";
  const date=str(draft.date), time=str(draft.time);
  function meetingLabel(){
    const savedMeeting=str(meeting.time)||str(payload.meeting_time);
    if(savedMeeting)return savedMeeting;
    if(date){
      const m=date.match(/^(\d{4})-(\d{2})-(\d{2})$/);
      if(m){const d=new Date(Number(m[1]),Number(m[2])-1,Number(m[3]));const ds=d.toLocaleDateString(undefined,{day:"numeric",month:"short",year:"numeric"});return ds+(time?` · ${time}`:"");}
    }
    return "Not available in the saved setup";
  }
  function dateTime(v){
    const raw=str(v); if(!raw)return "";
    const d=new Date(raw); return Number.isNaN(d.getTime())?raw:d.toLocaleString(undefined,{dateStyle:"medium",timeStyle:"short"});
  }
  function dateLabel(v){
    const raw=str(v);if(!raw)return "";
    const m=raw.match(/^(\d{4})-(\d{2})-(\d{2})$/);
    if(m){const d=new Date(Number(m[1]),Number(m[2])-1,Number(m[3]));return d.toLocaleDateString(undefined,{dateStyle:"medium"});}
    return dateTime(raw);
  }
  const completedAt=str(research.completed_at)||str(research.completion_time)||str(research.finished_at)||(statusLower==="completed"?str(research.updated_at):"");
  const generatedAt=str(briefing.generated_at);
  const sourceList=arr(briefing.sources);
  const sourceAnchors=new Map();
  sourceList.forEach((s,i)=>{const x=obj(s),id=str(x.source_id)||str(x.sourceId);if(id&&!sourceAnchors.has(id))sourceAnchors.set(id,`report-source-${i+1}`);});
  const warnings=arr(briefing.warnings).map(str).filter(Boolean);

  function refs(ids){
    return [...new Set(arr(ids).map(str).filter(id=>id&&sourceAnchors.has(id)))].map(id=>{
      const anchor=sourceAnchors.get(id);
      return `<a class="source-ref" href="#${esc(anchor)}" aria-label="Open source ${esc(id)}">[${esc(id)}]</a>`;
    }).join("");
  }
  function itemParts(item){
    if(typeof item==="string"||typeof item==="number")return {text:str(item)};
    const x=obj(item);
    return {text:str(x.text)||str(x.finding)||str(x.name)||str(x.title)||str(x.description),title:str(x.name)||str(x.title),date:str(x.date),kind:str(x.kind),verification:str(x.verification_status),confidence:str(x.confidence_status)||str(x.confidenceStatus),note:str(x.explanation)||str(x.note),refs:x.source_ids||x.sourceIds};
  }
  const CONFIDENCE_LABELS={supported:"Supported",partially_supported:"Partially supported",conflicting:"Conflicting",unsupported:"Unsupported",unverified:"Unverified",outdated:"Outdated"};
  function renderItems(items,{people=false,aiTag=false}={}){
    const values=listValues(items).map(itemParts).filter(x=>x.text);
    if(!values.length)return "";
    return `<ul class="report-list">${values.map(x=>{
      const aiItem=aiTag||/^(analysis)$/i.test(x.kind);
      const rawStatus=x.confidence||x.verification;
      const confidence=aiItem?"":(rawStatus==="verified"?"supported":rawStatus==="undated"?"unverified":rawStatus);
      const confidenceTag=confidence&&CONFIDENCE_LABELS[confidence]?`<span class="claim-status ${esc(confidence)}">${CONFIDENCE_LABELS[confidence]}</span>`:"";
      const title=people&&x.title?`<span class="item-title">${esc(x.title)}</span>${x.text!==x.title?` — ${esc(x.text)}`:""}`:esc(x.text);
      const date=x.date?`<time class="item-date">${esc(x.date)}</time>`:"";
      const tag=aiItem?`<span class="item-tag ai">AI analysis</span>`:"";
      const note=x.note?`<span class="item-note">${esc(x.note)}</span>`:"";
      return `<li class="report-item"><span>${title}${date}${tag}${confidenceTag}${refs(x.refs)}${note}</span></li>`;
    }).join("")}</ul>`;
  }
  function optionalItems(keys){
    for(const key of keys){
      const values=listValues(briefing[key]);
      if(values.length)return values;
    }
    return [];
  }
  const sections=[];
  function addSection(id,title,body,kicker=""){
    if(!body)return;
    sections.push({id,title,html:`<section class="report-section" id="section-${id}" aria-labelledby="title-${id}"><div class="section-heading"><span class="section-number">${String(sections.length+1).padStart(2,"0")}</span><div><h2 id="title-${id}">${esc(title)}</h2>${kicker?`<p class="section-kicker">${esc(kicker)}</p>`:""}</div></div>${body}</section>`});
  }

  const overview=str(briefing.overview), overviewItems=arr(briefing.overview_items);
  const executiveSummary=str(briefing.executive_summary), executiveSummaryItems=arr(briefing.executive_summary_items);
  const summaryBody=executiveSummaryItems.length?renderItems(executiveSummaryItems):executiveSummary?`<div class="report-copy"><p>${esc(executiveSummary)}</p></div>`:"";
  addSection("summary","Executive Summary",summaryBody);
  addSection("findings","Key Findings",renderItems(briefing.key_findings));
  const overviewBody=overviewItems.length?renderItems(overviewItems):overview?`<div class="report-copy"><p>${esc(overview)}</p></div>`:"";
  addSection("overview","Company Overview",overviewBody);

  const profile=[];
  const type=str(entity.type);
  const website=href(entity.website), linkedin=href(entity.linkedin_url);
  if(type&&type.toLowerCase()!=="unknown")profile.push(["Entity type",type]);
  if(website)profile.push(["Website",`<a href="${escapeUrl(website)}" target="_blank" rel="noopener noreferrer">${esc(website)}</a>`]);
  if(linkedin)profile.push(["LinkedIn",`<a href="${escapeUrl(linkedin)}" target="_blank" rel="noopener noreferrer">${esc(linkedin)}</a>`]);
  if(profile.length)addSection("profile","Company Profile",`<dl class="profile-grid">${profile.map(([label,value])=>`<div class="profile-field"><dt>${esc(label)}</dt><dd>${value}</dd></div>`).join("")}</dl>`);

  const business=arr(briefing.business_insights);
  addSection("business","Business Intelligence",renderItems(business,{aiTag:!ai.analysis_available&&business.some(x=>str(obj(x).kind)==="analysis")}));

  const products=optionalItems(["products_services","products_and_services","products","services"]);
  addSection("products","Products and Services",renderItems(products));

  const people=arr(briefing.key_people).map(p=>{const x=obj(p);return {name:str(x.name),text:str(x.role),role:str(x.role),source_ids:x.source_ids,kind:str(x.verification_status),confidence_status:str(x.confidence_status)};}).filter(p=>p.name).map(p=>({...p,title:p.name,text:p.role||p.name}));
  addSection("people","Key People and Management",renderItems(people,{people:true}),"Leadership and people identified in the returned research.");

  const competitors=optionalItems(["competitor_analysis","competitors","competitor_information"]);
  addSection("competitors","Competitor Analysis",renderItems(competitors));

  const industryTags=arr(briefing.industry_tags).map(str).filter(Boolean);
  const industry=arr(briefing.industry_information);
  const marketBody=`${industryTags.length?`<div class="tag-group"><p class="tag-group-label">AI-generated research tags</p><ul class="tag-list">${industryTags.map(tag=>`<li>${esc(tag)} <span class="item-tag ai">AI analysis</span></li>`).join("")}</ul></div>`:""}${renderItems(industry)}`;
  addSection("market","Market Research",marketBody);

  const developments=arr(briefing.recent_developments), news=arr(briefing.important_news), undated=arr(briefing.undated_information);
  const newsBody=`${developments.length?`<h3 class="subsection-title">Recent developments</h3>${renderItems(developments)}`:""}${news.length?`<h3 class="subsection-title">Latest news</h3>${renderItems(news)}`:""}${undated.length?`<div class="notes-box">Information below is grounded in retrieved sources but was not confirmed as recent.</div>${renderItems(undated)}`:""}`;
  addSection("news","Latest News and Developments",newsBody);

  const talking=arr(briefing.meeting_talking_points), questions=arr(briefing.suggested_questions), risks=arr(briefing.potential_risks), opportunities=arr(briefing.opportunities), openQuestions=arr(briefing.open_questions);
  const meetingPurpose=str(meeting.purpose);
  const meetingBody=`${meetingPurpose?`<div class="notes-box"><strong>Purpose:</strong> ${esc(meetingPurpose)}</div>`:""}${talking.length?`<h3 class="subsection-title">Talking points</h3>${renderItems(talking,{aiTag:true})}`:""}${questions.length?`<h3 class="subsection-title">Suggested questions</h3>${renderItems(questions,{aiTag:true})}`:""}${risks.length?`<h3 class="subsection-title">Potential discussion risks</h3>${renderItems(risks,{aiTag:true})}`:""}${opportunities.length?`<h3 class="subsection-title">Potential opportunities</h3>${renderItems(opportunities,{aiTag:true})}`:""}${openQuestions.length?`<h3 class="subsection-title">Open questions</h3>${renderItems(openQuestions)}`:""}`;
  addSection("meeting","Meeting Intelligence",meetingBody);

  addSection("evidence","Evidence Assessment",renderItems(briefing.unverified_claims),"Partial support, conflicts, and unsupported claims are kept separate from supported findings.");

  function sourceMarkup(source,index){
    const s=obj(source), id=str(s.source_id)||str(s.sourceId)||`Source ${index+1}`, url=href(s.url), title=str(s.title)||url||id;
    const sourceTitle=url?`<a href="${escapeUrl(url)}" target="_blank" rel="noopener noreferrer">${esc(title)}</a>`:esc(title);
    let domain=str(s.domain);if(!domain&&url){try{domain=new URL(url).hostname.replace(/^www\./i,"");}catch(_){}}
    const published=str(s.published_date)||str(s.publishedAt), retrieved=str(s.retrieved_at)||str(s.retrievedAt);
    const freshness=str(s.date_status)==="out_of_window"?"Outside research window":str(s.date_status)==="undated"?"Publication date unverified":"";
    const meta=[domain,str(s.publisher),published?`Published ${dateLabel(published)}`:"Publication date unavailable",freshness,retrieved?`Retrieved ${dateTime(retrieved)}`:"Retrieval date unavailable",str(s.source_type).replace(/_/g," ")].filter(Boolean).join(" · ");
    const evidence=str(s.evidence_status)||(/verified/i.test(str(s.verification_status))?"supporting":"uncited");
    const evidenceLabels={supporting:"Supports claim text",partial:"Partial evidence",conflicting:"Conflicting evidence",mixed:"Mixed evidence",uncited:"Not mapped to a claim"};
    const excerpt=str(s.snippet)||str(s.excerpt);
    const supports=arr(s.supports_claims).map(str).filter(Boolean);
    const partials=arr(s.partially_supports_claims).map(str).filter(Boolean), conflicts=arr(s.conflicts_with_claims).map(str).filter(Boolean);
    const evidenceClass=Object.prototype.hasOwnProperty.call(evidenceLabels,evidence)?evidence:"uncited";
    return `<article class="source-card" id="${esc(sourceAnchors.get(id)||`report-source-${index+1}`)}"><div class="source-top"><div class="source-heading"><span class="source-id">${esc(id)}</span><div class="source-title">${sourceTitle}</div></div><span class="source-status ${esc(evidenceClass)}">${esc(evidenceLabels[evidenceClass])}</span></div>${meta?`<p class="source-meta">${esc(meta)}</p>`:""}${excerpt?`<p class="source-excerpt">${esc(excerpt)}</p>`:""}${supports.length?`<p class="source-support">Supports claims: ${supports.map(esc).join(", ")}</p>`:""}${partials.length?`<p class="source-support partial">Partially supports: ${partials.map(esc).join(", ")}</p>`:""}${conflicts.length?`<p class="source-support conflict">Conflicts with: ${conflicts.map(esc).join(", ")}</p>`:""}</article>`;
  }
  addSection("sources","Research Sources and References",sourceList.length?`<div class="source-list">${sourceList.map(sourceMarkup).join("")}</div>`:"");

  const limitations=arr(briefing.limitations).map(str).filter(Boolean);
  const missingInformation=arr(briefing.missing_information);
  const limitationBody=`${limitations.length?renderItems(limitations):""}${missingInformation.length?`<h3 class="subsection-title">Missing information</h3>${renderItems(missingInformation)}`:""}`;
  addSection("limitations","Limitations and Missing Information",limitationBody);

  if(!sections.length){
    state("No report details returned",warnings.length?warnings.slice(0,3).join(" "):"The saved research response contained no displayable company findings or sources. VelQora has not filled in missing details.","empty");
    return;
  }

  const claimTotal=Number(summary.total_claims)||0, verified=Number(summary.verified_claims)||0;
  const totalSources=sourceList.length;
  const periodLabel=str(period.start_date)&&str(period.end_date)?`${str(period.start_date)} – ${str(period.end_date)}`:"";
  const partial=warnings.length>0||ai.analysis_available===false;
  const partialDetail=warnings.length?warnings.slice(0,3).join(" "):(ai.analysis_available===false?"AI analysis was unavailable for this report.":"");
  const statusClass=statusLower==="failed"?"failed":(["queued","running","in_progress"].includes(statusLower)?"in-progress":(statusLower==="completed"?"":"unknown"));
  const meta=[
    {label:"Original research query",value:query,className:"query"},
    {label:"Company",value:company},
    {label:"Selected meeting",value:meetingLabel()},
    {label:"Research depth",value:researchDepth},
    {label:"Research status",value:status,className:"status"},
    ...(completedAt?[{label:"Research completed",value:dateTime(completedAt)}]:[]),
    ...(!completedAt&&generatedAt?[{label:"Report generated",value:dateTime(generatedAt)}]:[])
  ];
  const partialCount=Number(summary.partially_supported)||0, conflictingCount=Number(summary.conflicting)||0;
  const chips=[...(claimTotal>0?[`<span class="summary-chip"><strong>${esc(verified)}</strong> supported by source text of ${esc(claimTotal)} claims</span>`]:[]),...(partialCount?[`<span class="summary-chip uncertain"><strong>${esc(partialCount)}</strong> partially supported</span>`]:[]),...(conflictingCount?[`<span class="summary-chip conflict"><strong>${esc(conflictingCount)}</strong> conflicting</span>`]:[]),...(totalSources?[`<span class="summary-chip"><strong>${esc(totalSources)}</strong> research sources</span>`]:[]),...(periodLabel?[`<span class="summary-chip">Research period <strong>${esc(periodLabel)}</strong></span>`]:[])];
  root.setAttribute("aria-busy","false");
  root.innerHTML=`<section class="report-hero" aria-labelledby="reportTitle"><div class="report-hero-inner">
    <div class="report-eyebrow"><span class="dot"></span>VelQora · Research report</div>
    <h1 id="reportTitle">Company Intelligence Report</h1><p class="report-company">${esc(company)}</p>
    <dl class="report-meta">${meta.map(m=>`<div class="report-meta-item ${esc(m.className||"")}"><dt>${esc(m.label)}</dt><dd>${m.className==="status"?`<span class="status-led ${statusClass}" aria-hidden="true"></span>`:""}${esc(m.value)}</dd></div>`).join("")}</dl>
    ${chips.length?`<div class="report-summary">${chips.join("")}</div>`:""}
    ${partial?`<p class="partial-note">Some research components were unavailable. The report includes only information returned by the research engine.${partialDetail?` ${esc(partialDetail)}`:""}</p>`:""}
  </div></section>
  <div class="report-layout"><aside class="report-sidebar" aria-label="Report sections"><p class="sidebar-label">In this report</p><nav class="report-nav">${sections.map((s,i)=>`<a href="#section-${esc(s.id)}"><span class="nav-index">${String(i+1).padStart(2,"0")}</span><span>${esc(s.title)}</span></a>`).join("")}</nav></aside>
    <div class="report-content">${sections.map(s=>s.html).join("")}<footer class="report-foot"><span>Evidence labels describe text matching in retrieved sources; they do not certify source reliability or objective truth.</span><span class="report-actions"><button type="button" id="printReport">Print report</button><a href="research-setup.html">Back to setup ↑</a></span></footer></div></div>`;

  const printButton=$("#printReport");
  if(printButton)printButton.addEventListener("click",()=>window.print());
  const navLinks=$$(".report-nav a");
  if("IntersectionObserver" in window){
    const sectionsEls=$$(".report-section");
    const observer=new IntersectionObserver(entries=>{
      const visible=entries.filter(e=>e.isIntersecting).sort((a,b)=>a.boundingClientRect.top-b.boundingClientRect.top)[0];
      if(!visible)return;
      navLinks.forEach(a=>a.classList.toggle("active",a.hash===`#${visible.target.id}`));
    },{rootMargin:"-15% 0px -70% 0px",threshold:0});
    sectionsEls.forEach(section=>observer.observe(section));
  }
  }

  const MAX_WAIT_MS=8*60*1000;
  const wait=ms=>new Promise(resolve=>setTimeout(resolve,ms));
  let loading=false;
  function showProgress(message,research){
    const data=obj(research), progress=Number(data.progress);
    const hasProgress=Number.isFinite(progress)&&progress>=0&&progress<=100;
    const label=str(data.message)||str(message)||"Research is in progress.";
    root.setAttribute("aria-busy","true");
    root.innerHTML=`<section class="report-state loading-state" role="status"><span class="state-spinner" aria-hidden="true"></span><p class="report-eyebrow state-eyebrow">VelQora · Live research</p><h1>Preparing your intelligence report</h1><p>${esc(label)}</p>${hasProgress?`<div class="research-progress" aria-label="Server-reported research progress"><progress max="100" value="${Math.round(progress)}"></progress><span>${Math.round(progress)}%</span></div>`:""}<p class="state-hint">This page will show the report when the research service finishes.</p></section>`;
  }
  async function poll(fetcher,onUpdate){
    const startedAt=Date.now(); let failures=0;
    while(Date.now()-startedAt<MAX_WAIT_MS){
      await wait(Date.now()-startedAt>30000?2000:1100);
      try{
        const value=await fetcher(); failures=0; onUpdate(value);
        if(value.status==="completed"||value.status==="failed")return value;
      }catch(error){ if([401,404,422].includes(error.status)||++failures>=4)throw error; }
    }
    throw new VQApi.ApiError(0,"client_timeout","Research is taking longer than expected. You can retry the status check safely.");
  }
  async function loadReport(){
    if(loading)return; loading=true;
    const requestedId=new URLSearchParams(location.search).get("id");
    let job=obj(read(KEY.job)), saved=obj(read(KEY.result));
    const researchId=requestedId||str(job.research_id)||str(saved.research_id);
    try{
      // A URL ID is authoritative: refresh that same backend job even if a report is cached.
      if(!requestedId&&saved.briefing&&saved.research_id){renderReport(saved);return;}
      if(!researchId){state("No research job found","Return to setup to enter your research details and start a report.");return;}
      if(!job.research_id||job.research_id!==researchId){job={research_id:researchId,status:"running",payload:{name:draft.company,research_query:draft.query}};write(KEY.job,job);}
      const update=value=>{
        job={...job,status:value.status||job.status,progress:value.progress,message:value.message||job.message,
          briefing_id:value.briefing_id||job.briefing_id,payload:job.payload||{}};
        write(KEY.job,job); showProgress(job.message,value);
      };
      showProgress(job.message||"Connecting to the research service…",{progress:job.progress,message:job.message});
      let research=await VQApi.getResearch(researchId);
      if(str(research.research_id)&&str(research.research_id)!==researchId)
        throw new VQApi.ApiError(502,"research_id_mismatch","The research service returned a different job than the one requested.");
      update(research);
      if(research.status!=="completed"&&research.status!=="failed") research=await poll(()=>VQApi.getResearch(researchId),update);
      if(research.status==="failed"){
        const failure=obj(research.error); job={...job,status:"failed"}; write(KEY.job,job);
        state("Research could not be completed",str(failure.message)||str(research.message)||"The research service reported a failure. Return to setup to try again.","error");return;
      }
      const briefingId=str(research.briefing_id)||str(job.briefing_id);
      if(!briefingId)throw new VQApi.ApiError(502,"no_briefing","Research finished but no report ID was returned.");
      showProgress("Preparing the report from the completed research…",research);
      let response=await VQApi.getBriefing(briefingId);
      if(response.status!=="completed"&&response.status!=="failed"){
        response=await poll(()=>VQApi.getBriefing(briefingId),value=>showProgress(value.message||"Preparing the report…",research));
      }
      if(response.status!=="completed"||!response.briefing){
        const failure=obj(response.error); job={...job,status:"failed"}; write(KEY.job,job);
        state("Research report is unavailable",str(failure.message)||"The research finished, but no completed report was returned. Return to setup to try again.","error");return;
      }
      if(str(response.research_id)&&str(response.research_id)!==researchId)
        throw new VQApi.ApiError(502,"briefing_research_mismatch","The report does not belong to the requested research job.");
      const entity=obj(research.entity), meeting=obj(response.briefing.meeting);
      const cachedPayload=obj(job.payload);
      const result={sig:str(job.sig),research_id:researchId,briefing_id:briefingId,
        payload:Object.keys(cachedPayload).length?cachedPayload:{name:str(entity.name),research_query:str(research.research_query)||str(response.briefing.research_query),
          research_depth:str(research.research_depth)||str(response.briefing.research_depth),meeting_time:str(meeting.time),purpose:str(meeting.purpose),url:str(entity.website)},
        research,briefing:response.briefing,ts:Date.now()};
      write(KEY.result,result); write(KEY.job,{...job,status:"completed",briefing_id:briefingId,progress:100});
      renderReport(result);                                      // render the API response even if storage is unavailable
    }catch(error){
      console.error("[VelQora report]",error);
      const terminal=error.status===404||error.status===422||error.code==="briefing_failed";
      if(terminal){job={...job,status:"failed"};write(KEY.job,job);}
      const retryable=!terminal&&(!error.status||error.status>=500);
      state("Unable to load the research report",str(error.message)||"The report could not be loaded. Please try again.","error",retryable?loadReport:null);
    }finally{loading=false;}
  }
  loadReport();
})();
