/* ============================================================
   VelQora research flow (landing-page input card).
   Real inputs are handed to Page 2. Page 2 submits the only research request; Page 3 follows that job.
   If browser session storage is unavailable, explain the issue and stop instead of bypassing the pages.
   ============================================================ */
(function(){
  const goBtn=$("#goBtn");
  if(!goBtn) return;                                  // not the landing page

  const prog=$("#prog"), bar=prog?prog.querySelector("i"):null;
  const statusTxt=$("#statusTxt"), badge=$("#badge"), msg=$("#vqMsg");
  const inputs=[["i1","t1","f1"],["i2","t2","f2"],["i3","t3","f3"],["i4","t4","f4"]].map(([i,t,f])=>({input:$("#"+i),demo:$("#"+t),wrap:$("#"+f)}));
  let running=false, demoActive=true;

  /* ---------- small UI helpers ---------- */
  const setStatus=t=>{ statusTxt.textContent=t; badge.setAttribute("title",t); };
  const setProgress=p=>{ if(bar) bar.style.width=Math.max(0,Math.min(100,p))+"%"; };
  const showMsg=(t,kind)=>{ if(!t){ msg.hidden=true; msg.textContent=""; return; } msg.textContent=t; msg.className="vq-msg"+(kind==="info"?" info":""); msg.hidden=false; };
  const setBusy=b=>{
    goBtn.classList.toggle("busy",b); badge.classList.toggle("busy",b);
    inputs.forEach(x=>{x.input.disabled=b;});
    if(b) goBtn.textContent="Researching…";
  };

  /* ---------- the original "typing" intro, now cosmetic only (it never starts research) ---------- */
  const demo=[["t1","Aurelia Systems","f1"],["t2","linkedin.com/company/aurelia","f2"],["t3","Fri, 14 Nov · 11:00","f3"],["t4","Partnership call","f4"]];
  const stopDemo=()=>{
    if(!demoActive) return;
    demoActive=false;
    $$(".caret").forEach(c=>c.remove());
    inputs.forEach(x=>{ x.demo.textContent=""; });
    $$(".inp").forEach(b=>{ if(document.activeElement!==b.querySelector("input")) b.classList.remove("focus"); });
  };
  async function typeDemo(){
    for(const [id,text,box] of demo){
      if(!demoActive) return;
      $$(".inp").forEach(b=>b.classList.remove("focus"));
      $$(".caret").forEach(c=>c.remove());
      const el=$("#"+id), wrap=$("#"+box); wrap.classList.add("focus");
      el.textContent=""; const c=document.createElement("i"); c.className="caret"; wrap.appendChild(c);
      for(const ch of text){ if(!demoActive) return; el.textContent+=ch; if(!reduce) await sleep(34); }
      if(!reduce) await sleep(200);
    }
    if(!demoActive) return;
    $$(".caret").forEach(c=>c.remove());
    $$(".inp").forEach(b=>b.classList.remove("focus"));
  }

  /* real inputs: hide the demo text while the user is typing in a field */
  inputs.forEach(({input,wrap})=>{
    const sync=()=>wrap.classList.toggle("vq-active",document.activeElement===input||input.value!=="");
    input.addEventListener("focus",()=>{ stopDemo(); sync(); });
    input.addEventListener("input",sync);
    input.addEventListener("blur",sync);
    input.addEventListener("keydown",e=>{ if(e.key==="Enter"){ e.preventDefault(); start(); } });
  });

  /* ---------- mandatory Page 1 → Page 2 hand-off ---------- */
  async function start(){
    if(running) return;                                              // no duplicate submissions
    showMsg("");
    const val=x=>x.input.value.trim();
    const name=val(inputs[0]);
    if(!name){
      stopDemo();
      setStatus("Enter a name to start");
      showMsg("Type the company or person you're meeting, then press Start Research.","error");
      inputs[0].input.focus();
      return;
    }
    running=true; stopDemo(); setBusy(true); setProgress(0);
    setStatus("Opening research setup…");
    try{
      sessionStorage.removeItem("vq.setup.form");
      sessionStorage.removeItem("vq.job");
      sessionStorage.removeItem("vq.result");
      sessionStorage.setItem("vq.handoff",JSON.stringify({query:name,url:val(inputs[1]),meeting_time:val(inputs[2]),purpose:val(inputs[3]),ts:Date.now()}));
      location.href="research-setup.html";
    }catch(e){
      console.error("[VelQora handoff]",e);
      running=false; setBusy(false);
      setProgress(0);
      setStatus("Research setup unavailable");
      showMsg("VelQora couldn't save your details for the research setup page. Allow session storage in your browser and try again. Research was not started.","error");
      goBtn.textContent="Try Again →";
    }
  }

  goBtn.addEventListener("click",start);

  /* returning from Page 2 ("Back to Home"): restore what the user typed */
  try{
    const h=JSON.parse(sessionStorage.getItem("vq.handoff")||"null");
    if(h&&h.query){
      stopDemo();
      [h.query,h.url,h.meeting_time,h.purpose].forEach((v,i)=>{ if(v){ inputs[i].input.value=v; inputs[i].input.dispatchEvent(new Event("input")); } });
    }
  }catch(_){}

  /* ---------- boot ---------- */
  VelQora.renderIdle();                                   // skeleton, exactly as before
  setProgress(0);
  if(reduce){ demo.forEach(([id,t])=>{ $("#"+id).textContent=t; }); }
  else setTimeout(typeDemo,1700);
  VQApi.health().catch(e=>{
    if(e.code==="network") showMsg("The VelQora backend isn't reachable yet. Start it (see README), then reload this page.","error");
  });
})();
