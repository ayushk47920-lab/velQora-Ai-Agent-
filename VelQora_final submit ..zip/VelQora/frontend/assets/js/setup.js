/* ============================================================
   VelQora — Page 2: research configuration.
   Talks to the backend ONLY through the existing VQApi client (startResearch / getResearch / getBriefing),
   sends only fields the existing ResearchRequest schema accepts, and mirrors the polling logic in research.js.
   State (sessionStorage): vq.handoff (from Page 1), vq.setup.form (draft), vq.job (single submitted job), vq.result (Page 3 report).
   ============================================================ */
(function(){
  const form=$("#setupForm"); if(!form) return;
  /* Page 3 continues the submitted job; it never starts a second research POST. */
  const PAGE3_URL="research-results.html";

  const KEY={handoff:"vq.handoff",draft:"vq.setup.form",job:"vq.job",result:"vq.result"};
  const store={
    get(k){try{return JSON.parse(sessionStorage.getItem(k)||"null");}catch(_){return null;}},
    set(k,v){try{sessionStorage.setItem(k,JSON.stringify(v));}catch(_){}},
    del(k){try{sessionStorage.removeItem(k);}catch(_){}}
  };
  const el={q:$("#qInput"),c:$("#cInput"),d:$("#dInput"),t:$("#tInput"),url:$("#urlInput"),purpose:$("#purposeInput"),
    meetingNote:$("#meetingTransferNote"),depth:$("#depthInput"),btn:$("#startBtn"),run:$("#run"),runTxt:$("#runTxt"),
    runPct:$("#runPct"),runBar:$("#runBar"),msg:$("#setupMsg"),done:$("#done"),doneLink:$("#doneLink")};
  let running=false;

  /* ---------- date helpers (local time) ---------- */
  const pad=n=>String(n).padStart(2,"0");
  const today=()=>{const n=new Date();return `${n.getFullYear()}-${pad(n.getMonth()+1)}-${pad(n.getDate())}`;};
  el.d.min=today();
  const MON=["Jan","Feb","Mar","Apr","May","Jun","Jul","Aug","Sep","Oct","Nov","Dec"], DOW=["Sun","Mon","Tue","Wed","Thu","Fri","Sat"];
  /* "Fri, 14 Nov 2026 · 11:00" — the same free-text style the existing backend date parser already understands */
  function meetingText(d,t){
    const [y,m,day]=d.split("-").map(Number);
    return `${DOW[new Date(y,m-1,day).getDay()]}, ${day} ${MON[m-1]} ${y} · ${t}`;
  }
  function parseMeeting(value){
    const raw=String(value||"").trim();
    const iso=raw.match(/^(\d{4}-\d{2}-\d{2})(?:[ T](\d{2}:\d{2}))?/);
    if(iso)return {date:iso[1],time:iso[2]||""};
    if(!/\b\d{4}\b/.test(raw))return null;                // never invent a year for a partial date
    const parsed=new Date(raw.replace(/[·,]/g," ").replace(/\s+/g," "));
    if(Number.isNaN(parsed.getTime()))return null;
    return {date:`${parsed.getFullYear()}-${pad(parsed.getMonth()+1)}-${pad(parsed.getDate())}`,
      time:`${pad(parsed.getHours())}:${pad(parsed.getMinutes())}`};
  }

  /* ---------- initial values: draft > hand-off from Page 1 ---------- */
  const handoff=store.get(KEY.handoff)||{};
  const draft=store.get(KEY.draft);
  if(draft){ el.q.value=draft.query||""; el.c.value=draft.company||""; el.d.value=draft.date||""; el.t.value=draft.time||"";
    el.url.value=draft.url||handoff.url||"";el.purpose.value=draft.purpose||handoff.purpose||"";el.depth.value=draft.depth||"standard"; }
  else{
    el.q.value=(handoff.query||"").slice(0,200);
    el.c.value=(handoff.query||"").slice(0,120);          // sensible starting point; fully editable
    el.url.value=(handoff.url||"").slice(0,300);el.purpose.value=(handoff.purpose||"").slice(0,200);
    if(handoff.meeting_time){
      const meeting=parseMeeting(handoff.meeting_time);
      if(meeting){el.d.value=meeting.date;el.t.value=meeting.time;}
      else if(el.meetingNote){el.meetingNote.textContent=`Meeting time received from Page 1: ${handoff.meeting_time}. Confirm the date and time below.`;el.meetingNote.hidden=false;}
    }
  }
  const saveDraft=()=>store.set(KEY.draft,{query:el.q.value,company:el.c.value,date:el.d.value,time:el.t.value,
    url:el.url.value,purpose:el.purpose.value,depth:el.depth.value});
  const formInputs=[el.q,el.c,el.d,el.t,el.url,el.purpose,el.depth],validatedInputs=[el.q,el.c,el.d,el.t];
  formInputs.forEach(i=>i.addEventListener("input",()=>{saveDraft();if(validatedInputs.includes(i))clearErr(i);if(!running)el.done.hidden=true;}));
  el.depth.addEventListener("change",saveDraft);
  /* Keep Page 1's company/name field separate from the research question. */
  $("#backHome").addEventListener("click",()=>{
    const h=store.get(KEY.handoff)||{};h.query=el.c.value.trim()||h.query||"";h.url=el.url.value.trim();
    h.purpose=el.purpose.value.trim();h.meeting_time=el.d.value&&el.t.value?meetingText(el.d.value,el.t.value):(h.meeting_time||"");store.set(KEY.handoff,h);
  });

  /* ---------- validation ---------- */
  const fieldOf=i=>i.closest(".sfield");
  function setErr(input,text){
    const f=fieldOf(input), p=f.querySelector(".serr");
    f.classList.add("invalid"); input.setAttribute("aria-invalid","true"); p.textContent=text; p.hidden=false;
  }
  function clearErr(input){
    const f=fieldOf(input), p=f.querySelector(".serr");
    f.classList.remove("invalid"); input.removeAttribute("aria-invalid"); p.hidden=true; p.textContent="";
  }
  function validate(){
    [el.q,el.c,el.d,el.t].forEach(clearErr);
    let first=null; const bad=(i,t)=>{ setErr(i,t); first=first||i; };
    const q=el.q.value.trim(), c=el.c.value.trim();
    if(!q) bad(el.q,"Enter what you'd like to research.");
    if(!c) bad(el.c,"Enter the company name.");
    else if(c.length<2) bad(el.c,"Company name must be at least 2 characters.");
    if(!el.d.value) bad(el.d,"Choose the meeting date.");
    else if(el.d.value<today()) bad(el.d,"The meeting date can't be in the past.");
    if(!el.t.value) bad(el.t,"Choose the meeting time.");
    else if(el.d.value===today()){
      const n=new Date(); if(el.t.value<`${pad(n.getHours())}:${pad(n.getMinutes())}`) bad(el.t,"That time has already passed today.");
    }
    if(first){ first.focus(); return false; }
    return true;
  }

  /* ---------- payload: existing fields plus optional, backward-compatible query/depth controls ---------- */
  function buildPayload(){
    const query=el.q.value.trim(), company=el.c.value.trim();
    const purpose=el.purpose.value.trim();
    return {
      name:company,
      research_query:query,
      research_depth:el.depth.value,
      url:el.url.value.trim()||null,
      meeting_time:meetingText(el.d.value,el.t.value),
      purpose:purpose.slice(0,200)||null,
      auto_brief:true
    };
  }
  const sig=p=>JSON.stringify(p);

  /* ---------- UI ---------- */
  const showMsg=(t,kind)=>{ const m=el.msg; if(!t){m.hidden=true;m.textContent="";return;} m.textContent=t; m.className="vq-msg"+(kind==="info"?" info":""); m.hidden=false; };
  function setBusy(b){
    running=b;
    el.btn.disabled=b; el.btn.setAttribute("aria-busy",String(b));
    formInputs.forEach(i=>{i.disabled=b;});
    form.classList.toggle("locked",b);
    el.run.hidden=!b;
    if(b){ el.btn.firstChild.textContent="Researching… "; el.done.hidden=true; }
    else el.btn.firstChild.textContent="Start AI Research ";
  }
  function pageThree(researchId){
    return PAGE3_URL+"?id="+encodeURIComponent(researchId);
  }
  function openReport(researchId){
    if(researchId) location.assign(pageThree(researchId));
  }

  /* Page 2 submits one real job, then Page 3 owns status checks and report rendering. */
  async function run(payload){
    if(running) return;
    setBusy(true); showMsg("");
    el.runTxt.textContent="Connecting to the research engine…";
    el.runPct.textContent="";
    el.runBar.style.width="0%";
    const requestSig=sig(payload);
    try{
      const started=await VQApi.startResearch(payload);             // the only POST for this request
      if(!started||!started.research_id) throw new VQApi.ApiError(502,"invalid_response","The research service did not return a job ID.");
      const job={sig:requestSig,research_id:started.research_id,status:started.status||"queued",payload,
        progress:started.progress,message:started.message||"Research request accepted."};
      store.set(KEY.job,job);
      store.del(KEY.result);
      openReport(job.research_id);                                   // continue on Page 3, without a second API request
    }catch(e){
      console.error("[VelQora]",e);
      setBusy(false);
      showMsg(e.message||"Something went wrong. Please try again.","error");
      el.btn.firstChild.textContent="Try again ";
    }
  }

  form.addEventListener("submit",e=>{
    e.preventDefault();
    if(running) return;
    if(!validate()) return;
    const payload=buildPayload(), requestSig=sig(payload);
    saveDraft();
    const job=store.get(KEY.job), result=store.get(KEY.result);
    if(result&&result.sig===requestSig&&result.research_id){ openReport(result.research_id); return; }
    if(job&&job.sig===requestSig&&job.research_id&&job.status!=="failed") { openReport(job.research_id); return; }
    if(job&&job.sig===requestSig&&job.status==="failed") store.del(KEY.job);
    run(payload);
  });

  /* If the user returns from Page 3, keep the same job available without starting another POST. */
  (function resume(){
    const job=store.get(KEY.job), result=store.get(KEY.result);
    if(result&&job&&result.sig===job.sig&&result.research_id){
      el.done.hidden=false; el.doneLink.href=pageThree(result.research_id); el.doneLink.textContent="View saved results →";
      el.btn.firstChild.textContent="Run again with changes "; return;
    }
    if(job&&job.research_id&&job.status!=="failed"){
      el.done.hidden=false; el.doneLink.href=pageThree(job.research_id); el.doneLink.textContent="Continue to research →";
    }
  })();
})();
